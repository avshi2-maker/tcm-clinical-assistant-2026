// ═══════════════════════════════════════════════════════════════
// MODULE: TIMER-METRICS.JS
// PURPOSE: Session clock, query timer, cost calculator
// DATE: February 3, 2026
// FOR: Avshi (Shows time and costs!)
// ═══════════════════════════════════════════════════════════════

console.log('📦 Loading Timer-Metrics module...');

// ═══════════════════════════════════════════════════════════════
// STATE VARIABLES
// ═══════════════════════════════════════════════════════════════

let queryStartTime = 0;
let queryEndTime = 0;
let queryTimerInterval = null;
let timerInterval = null;

// ═══════════════════════════════════════════════════════════════
// MAIN FUNCTIONS
// ═══════════════════════════════════════════════════════════════

// FUNCTION 1: Start query timer (measures how long search takes)
function startQueryTimer() {
    const queryTimerEl = document.getElementById('queryTimer');
    if (!queryTimerEl) {
        console.warn('queryTimer element not found');
        return;
    }
    
    queryStartTime = Date.now();
    queryTimerEl.textContent = '0.00s';
    
    if (queryTimerInterval) {
        clearInterval(queryTimerInterval);
    }
    
    // Update every 100ms for smooth counting
    queryTimerInterval = setInterval(() => {
        if (!isPaused) {
            const elapsed = ((Date.now() - queryStartTime) / 1000).toFixed(2);
            const el = document.getElementById('queryTimer');
            if (el) {
                el.textContent = `${elapsed}s`;
            }
        }
    }, 100);
}

// FUNCTION 2: Stop query timer
function stopQueryTimer() {
    if (queryTimerInterval) {
        clearInterval(queryTimerInterval);
        queryTimerInterval = null;
    }
    
    const queryTimerEl = document.getElementById('queryTimer');
    if (!queryTimerEl) {
        console.warn('queryTimer element not found');
        return;
    }
    
    queryEndTime = Date.now();
    const totalTime = ((queryEndTime - queryStartTime) / 1000).toFixed(2);
    queryTimerEl.textContent = `${totalTime}s`;
}

// FUNCTION 3: Reset query timer
function resetQueryTimer() {
    if (queryTimerInterval) {
        clearInterval(queryTimerInterval);
        queryTimerInterval = null;
    }
    
    const queryTimerEl = document.getElementById('queryTimer');
    if (queryTimerEl) {
        queryTimerEl.textContent = '0.00s';
    }
}

// FUNCTION 4: Start session timer (golden clock at top)
function startSessionTimer() {
    function updateClock() {
        const sessionTimerEl = document.getElementById('sessionTimer');
        if (!sessionTimerEl) {
            console.warn('sessionTimer element not found');
            return;
        }
        
        const now = new Date();
        const timeStr = now.toLocaleTimeString('he-IL', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        });
        const dateStr = now.toLocaleDateString('he-IL', { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric' 
        });
        sessionTimerEl.textContent = `${timeStr} • ${dateStr}`;
    }
    
    updateClock(); // Update immediately
    timerInterval = setInterval(updateClock, 1000); // Update every second
}

// FUNCTION 5: Calculate AI costs (Gemini tokens)
function calculateCost(inputTokens, outputTokens) {
    const inputCost = inputTokens * INPUT_TOKEN_COST;   // $0.50 per 1M tokens
    const outputCost = outputTokens * OUTPUT_TOKEN_COST; // $3.00 per 1M tokens
    return inputCost + outputCost;
}

// FUNCTION 6: Update metrics display (tokens, cost, success rate)
function updateMetrics(newInputTokens = 0, newOutputTokens = 0) {
    totalInputTokens += newInputTokens;
    totalOutputTokens += newOutputTokens;
    totalCost = calculateCost(totalInputTokens, totalOutputTokens);
    
    const totalTokens = totalInputTokens + totalOutputTokens;
    
    // Update token count
    const tokenCountEl = document.getElementById('tokenCount');
    if (tokenCountEl) {
        tokenCountEl.textContent = totalTokens.toLocaleString();
    }
    
    // Update cost
    const totalCostEl = document.getElementById('totalCost');
    if (totalCostEl) {
        totalCostEl.textContent = `$${totalCost.toFixed(4)}`;
    }
    
    // Update assets searched
    const assetsEl = document.getElementById('assetsSearched');
    if (assetsEl) {
        assetsEl.textContent = totalAssets;
    }
    
    // Update success rate
    const successRateEl = document.getElementById('successRate');
    if (successRateEl) {
        const successRate = totalQueries > 0 
            ? Math.round((successfulQueries / totalQueries) * 100) 
            : 0;
        successRateEl.textContent = `${successRate}%`;
    }
}

// FUNCTION 7: Reset entire session
function resetSession() {
    if (confirm('להתחיל סשן חדש? זה ינקה את כל השאלות והתוצאות.')) {
        sessionStartTime = Date.now();
        totalInputTokens = 0;
        totalOutputTokens = 0;
        totalCost = 0;
        totalAssets = 0;
        successfulQueries = 0;
        totalQueries = 0;
        currentQueries = [];
        usedCSVs.clear();
        
        isSearching = false;
        isPaused = false;
        resetQueryTimer();
        
        clearAllQueries();
        document.getElementById('searchResults').innerHTML = '';
        document.getElementById('activeQueries').innerHTML = '';
        document.getElementById('shareButtons').classList.add('hidden');
        document.getElementById('reportOptions').classList.add('hidden');
        document.getElementById('fallbackBrowser').classList.add('hidden');
        
        document.getElementById('pauseSearchBtn').classList.add('hidden');
        document.getElementById('continueSearchBtn').classList.add('hidden');
        document.getElementById('stopSearchBtn').classList.add('hidden');
        
        resetCSVIndicators();
        updateMetrics();
    }
}

// FUNCTION 8: Pause/Continue/Stop search controls
function togglePause() {
    const pauseBtn = document.getElementById('pauseButton');
    
    if (isPaused) {
        isPaused = false;
        pauseBtn.textContent = '⏸️ השהה';
        pauseBtn.classList.remove('paused-state');
        updateStatus('✅ ממשיך בחיפוש...');
    } else {
        isPaused = true;
        pauseBtn.textContent = '▶️ המשך';
        pauseBtn.classList.add('paused-state');
        updateStatus('⏸️ מושהה - לחץ המשך כדי להמשיך');
        
        if (searchAbortController) {
            searchAbortController.abort();
            searchAbortController = null;
        }
    }
}

function pauseSearch() {
    if (!isSearching) return;
    
    isPaused = true;
    updateStatus('⏸️ חיפוש מושהה');
    
    document.getElementById('pauseSearchBtn').classList.add('hidden');
    document.getElementById('continueSearchBtn').classList.remove('hidden');
    
    if (queryTimerInterval) {
        clearInterval(queryTimerInterval);
        queryTimerInterval = null;
    }
}

function continueSearch() {
    if (!isSearching) return;
    
    isPaused = false;
    updateStatus('✅ ממשיך בחיפוש...');
    
    document.getElementById('pauseSearchBtn').classList.remove('hidden');
    document.getElementById('continueSearchBtn').classList.add('hidden');
    
    startQueryTimer();
}

function stopSearch() {
    if (!isSearching) return;
    
    isSearching = false;
    isPaused = false;
    
    if (queryTimerInterval) {
        clearInterval(queryTimerInterval);
        queryTimerInterval = null;
    }
    
    document.getElementById('pauseSearchBtn').classList.add('hidden');
    document.getElementById('continueSearchBtn').classList.add('hidden');
    document.getElementById('stopSearchBtn').classList.add('hidden');
    
    if (searchAbortController) {
        searchAbortController.abort();
        searchAbortController = null;
    }
    
    updateStatus('🔴 חיפוש הופסק על ידי המשתמש');
    document.getElementById('searchResults').innerHTML = `
        <div class="text-center p-8 text-red-600">
            <h3 class="text-2xl font-bold">🔴 חיפוש הופסק</h3>
            <p class="mt-2">החיפוש הופסק על ידי המשתמש</p>
        </div>
    `;
    
    queryEndTime = Date.now();
    const totalTime = ((queryEndTime - queryStartTime) / 1000).toFixed(2);
    document.getElementById('queryTimer').textContent = `${totalTime}s (הופסק)`;
}

// ═══════════════════════════════════════════════════════════════
// MAKE FUNCTIONS AVAILABLE TO HTML
// ═══════════════════════════════════════════════════════════════

window.startQueryTimer = startQueryTimer;
window.stopQueryTimer = stopQueryTimer;
window.resetQueryTimer = resetQueryTimer;
window.startSessionTimer = startSessionTimer;
window.calculateCost = calculateCost;
window.updateMetrics = updateMetrics;
window.resetSession = resetSession;
window.togglePause = togglePause;
window.pauseSearch = pauseSearch;
window.continueSearch = continueSearch;
window.stopSearch = stopSearch;

console.log('✅ Timer-Metrics module loaded successfully!');

// ═══════════════════════════════════════════════════════════════
// END OF MODULE
// ═══════════════════════════════════════════════════════════════
