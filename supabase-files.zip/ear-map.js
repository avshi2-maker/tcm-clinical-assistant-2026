/**
 * ═══════════════════════════════════════════════════════════════
 * 👂 EAR MAP MODULE - Auricular Acupuncture
 * ═══════════════════════════════════════════════════════════════
 * 
 * Upload to: Supabase Storage → modules → ear-map.js
 * Usage: EarMap.showModal()
 * 
 * ═══════════════════════════════════════════════════════════════
 */

console.log('👂 Loading Ear Map module...');

window.EarMap = (function() {
    
    const zones = {
        helix: { name: 'Helix', nameHe: 'גוף/ראש', color: '#FF6B6B', desc: 'מייצג את הגוף מבחוץ - אלרגיות, דלקות, כאבים חיצוניים.' },
        antihelix: { name: 'Antihelix', nameHe: 'עמוד שדרה', color: '#4ECDC4', desc: 'מייצג את עמוד השדרה כולו! מעולה לכאבי גב.' },
        concha: { name: 'Concha', nameHe: 'איברים פנימיים', color: '#9B59B6', desc: 'לב, ריאות, כבד, כליות, קיבה - הכל כאן.' },
        tragus: { name: 'Tragus', nameHe: 'אדרנל/תיאבון', color: '#F39C12', desc: 'נקודת הרעב נמצאת כאן - מעולה לדיאטה!' },
        antitragus: { name: 'Antitragus', nameHe: 'ראש/מוח', color: '#E74C3C', desc: 'כאבי ראש, סחרחורת, בעיות נוירולוגיות.' },
        lobe: { name: 'Lobe', nameHe: 'פנים/עיניים', color: '#3498DB', desc: 'עיניים, לסת, שיניים - הראש למטה כמו עובר.' }
    };
    
    const protocols = {
        pain: { name: 'כאב', points: ['Shenmen', 'Point Zero', 'Sympathetic'] },
        anxiety: { name: 'חרדה', points: ['Shenmen', 'Heart', 'Sympathetic'] },
        insomnia: { name: 'שינה', points: ['Shenmen', 'Heart', 'Kidney', 'Point Zero'] },
        addiction: { name: 'התמכרות (NADA)', points: ['Shenmen', 'Sympathetic', 'Kidney', 'Liver', 'Lung'] },
        weight: { name: 'משקל', points: ['Hunger', 'Stomach', 'Endocrine', 'Shenmen'] },
        headache: { name: 'כאב ראש', points: ['Shenmen', 'Point Zero', 'Sympathetic'] },
        digestion: { name: 'עיכול', points: ['Stomach', 'Liver', 'Shenmen', 'Sympathetic'] },
        stress: { name: 'לחץ', points: ['Shenmen', 'Sympathetic', 'Endocrine', 'Heart'] }
    };
    
    function generateHTML() {
        return `
        <style>
            .ear-map-container { font-family: Arial, sans-serif; direction: rtl; }
            .ear-map-content { display: flex; gap: 20px; flex-wrap: wrap; justify-content: center; }
            .ear-svg-wrapper { flex: 1; min-width: 280px; max-width: 350px; }
            .ear-controls { flex: 0 0 280px; }
            .ear-svg { width: 100%; height: auto; }
            .ear-zone { cursor: pointer; transition: all 0.3s; }
            .ear-zone:hover { filter: brightness(1.3); }
            .ear-zone.active { filter: brightness(1.5) drop-shadow(0 0 10px currentColor); }
            .ear-point { cursor: pointer; transition: all 0.2s; }
            .ear-point:hover { r: 8; }
            .ear-point.highlight { r: 8; fill: #FFD700; filter: drop-shadow(0 0 10px #FFD700); }
            .zone-btn { padding: 8px; border-radius: 8px; border: 2px solid; background: rgba(0,0,0,0.2); color: white; cursor: pointer; font-size: 11px; margin: 3px; transition: all 0.2s; }
            .zone-btn:hover { transform: scale(1.05); }
            .protocol-btn { padding: 6px 12px; border-radius: 20px; border: 1px solid #666; background: rgba(255,255,255,0.1); color: white; cursor: pointer; font-size: 11px; margin: 3px; }
            .protocol-btn:hover { background: #8B5CF6; }
            .ear-info { background: rgba(0,0,0,0.3); padding: 12px; border-radius: 8px; margin-top: 12px; display: none; }
            .ear-info.show { display: block; }
        </style>
        <div class="ear-map-container">
            <div class="ear-map-content">
                <div class="ear-svg-wrapper">
                    <svg class="ear-svg" viewBox="0 0 300 400">
                        <defs>
                            <linearGradient id="earGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#FFE4C4"/>
                                <stop offset="100%" style="stop-color:#DEB887"/>
                            </linearGradient>
                        </defs>
                        <path d="M 150,30 Q 220,40 240,100 Q 260,160 250,220 Q 240,280 220,320 Q 200,360 160,380 Q 120,390 100,370 Q 80,350 90,310 Q 100,270 90,230 Q 80,190 90,150 Q 100,110 120,80 Q 140,50 150,30" fill="url(#earGrad)" stroke="#8B7355" stroke-width="3"/>
                        <path id="zone-helix" class="ear-zone" data-zone="helix" d="M 150,35 Q 215,45 235,100 Q 250,150 245,200 Q 240,250 225,290" fill="none" stroke="#FF6B6B" stroke-width="12" stroke-linecap="round" opacity="0.6"/>
                        <path id="zone-antihelix" class="ear-zone" data-zone="antihelix" d="M 160,80 Q 180,120 175,180 Q 170,240 165,280" fill="none" stroke="#4ECDC4" stroke-width="15" stroke-linecap="round" opacity="0.6"/>
                        <ellipse id="zone-concha" class="ear-zone" data-zone="concha" cx="140" cy="220" rx="35" ry="45" fill="#9B59B6" opacity="0.5"/>
                        <ellipse id="zone-tragus" class="ear-zone" data-zone="tragus" cx="95" cy="200" rx="18" ry="25" fill="#F39C12" opacity="0.5"/>
                        <ellipse id="zone-antitragus" class="ear-zone" data-zone="antitragus" cx="120" cy="300" rx="20" ry="18" fill="#E74C3C" opacity="0.5"/>
                        <ellipse id="zone-lobe" class="ear-zone" data-zone="lobe" cx="130" cy="355" rx="30" ry="25" fill="#3498DB" opacity="0.5"/>
                        <g id="ear-points">
                            <circle class="ear-point" id="pt-shenmen" cx="175" cy="130" r="5" fill="#FFD700"/><text x="185" y="135" fill="#FFD700" font-size="9">Shenmen</text>
                            <circle class="ear-point" id="pt-zero" cx="155" cy="190" r="5" fill="#00FF00"/><text x="165" y="195" fill="#00FF00" font-size="9">Point Zero</text>
                            <circle class="ear-point" id="pt-sympathetic" cx="165" cy="105" r="5" fill="#FF69B4"/>
                            <circle class="ear-point" id="pt-heart" cx="130" cy="210" r="5" fill="#FF0000"/>
                            <circle class="ear-point" id="pt-lung" cx="150" cy="230" r="5" fill="#87CEEB"/>
                            <circle class="ear-point" id="pt-liver" cx="125" cy="240" r="5" fill="#228B22"/>
                            <circle class="ear-point" id="pt-kidney" cx="155" cy="250" r="5" fill="#000080"/>
                            <circle class="ear-point" id="pt-stomach" cx="140" cy="260" r="5" fill="#FFA500"/>
                            <circle class="ear-point" id="pt-hunger" cx="90" cy="185" r="5" fill="#FFA500"/>
                            <circle class="ear-point" id="pt-endocrine" cx="95" cy="230" r="5" fill="#00CED1"/>
                        </g>
                    </svg>
                </div>
                <div class="ear-controls">
                    <h4 style="margin:0 0 10px 0;">🗺️ אזורים</h4>
                    <div>${Object.entries(zones).map(([id, z]) => `<button class="zone-btn" style="border-color:${z.color};color:${z.color}" onclick="EarMap.selectZone('${id}')">${z.nameHe}</button>`).join('')}</div>
                    <h4 style="margin:15px 0 10px 0;">🩺 פרוטוקולים</h4>
                    <div>${Object.entries(protocols).map(([id, p]) => `<button class="protocol-btn" onclick="EarMap.showProtocol('${id}')">${p.name}</button>`).join('')}</div>
                    <div id="ear-info" class="ear-info">
                        <h4 id="ear-info-title"></h4>
                        <p id="ear-info-desc" style="font-size:12px;margin:8px 0;"></p>
                        <p id="ear-info-points" style="font-size:11px;"></p>
                    </div>
                </div>
            </div>
        </div>`;
    }
    
    return {
        show: function(containerId) {
            const c = document.getElementById(containerId);
            if (c) { c.innerHTML = generateHTML(); this._bindEvents(); }
        },
        showModal: function() {
            let m = document.getElementById('ear-modal');
            if (!m) {
                m = document.createElement('div');
                m.id = 'ear-modal';
                m.innerHTML = `<div style="position:fixed;inset:0;background:rgba(0,0,0,0.9);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;">
                    <div style="background:linear-gradient(135deg,#1a1a2e,#2d1b4e);border-radius:16px;max-width:800px;width:100%;max-height:90vh;overflow:auto;position:relative;padding:20px;">
                        <button onclick="EarMap.closeModal()" style="position:absolute;top:10px;left:10px;width:36px;height:36px;border-radius:50%;border:none;background:#e53e3e;color:white;font-size:20px;cursor:pointer;">✕</button>
                        <h2 style="text-align:center;color:white;margin-bottom:15px;">👂 מפת אוזן לאבחון וטיפול</h2>
                        <div id="ear-modal-content"></div>
                    </div>
                </div>`;
                document.body.appendChild(m);
            }
            m.style.display = 'block';
            document.body.style.overflow = 'hidden';
            this.show('ear-modal-content');
        },
        closeModal: function() {
            const m = document.getElementById('ear-modal');
            if (m) { m.style.display = 'none'; document.body.style.overflow = 'auto'; }
        },
        selectZone: function(id) {
            document.querySelectorAll('.ear-zone').forEach(z => z.classList.remove('active'));
            const zone = document.getElementById('zone-' + id);
            if (zone) zone.classList.add('active');
            const z = zones[id];
            if (z) {
                document.getElementById('ear-info').classList.add('show');
                document.getElementById('ear-info-title').innerHTML = `<span style="color:${z.color}">${z.name}</span> - ${z.nameHe}`;
                document.getElementById('ear-info-desc').textContent = z.desc;
                document.getElementById('ear-info-points').textContent = '';
            }
        },
        showProtocol: function(id) {
            document.querySelectorAll('.ear-point').forEach(p => p.classList.remove('highlight'));
            const p = protocols[id];
            if (p) {
                document.getElementById('ear-info').classList.add('show');
                document.getElementById('ear-info-title').textContent = '🩺 פרוטוקול ' + p.name;
                document.getElementById('ear-info-desc').textContent = '';
                document.getElementById('ear-info-points').innerHTML = '<strong>נקודות:</strong> ' + p.points.join(' • ');
                // Highlight points (simplified)
                p.points.forEach(pt => {
                    const el = document.getElementById('pt-' + pt.toLowerCase().replace(' ', ''));
                    if (el) el.classList.add('highlight');
                });
            }
        },
        _bindEvents: function() {
            document.querySelectorAll('.ear-zone').forEach(z => {
                z.addEventListener('click', () => this.selectZone(z.dataset.zone));
            });
        }
    };
})();

console.log('✅ Ear Map module loaded!');
console.log('   → EarMap.showModal()');
