// ═══════════════════════════════════════════════════════════════
// MODULE: SEARCH-ENGINE.JS
// PURPOSE: Core database search - searches all tables in Supabase
// DATE: February 3, 2026
// FOR: Avshi (This is the brain - searches your database!)
// ═══════════════════════════════════════════════════════════════

console.log('📦 Loading Search-Engine module...');

// ═══════════════════════════════════════════════════════════════
// STATE VARIABLES
// ═══════════════════════════════════════════════════════════════

let searchConfigCache = null; // Cache of which tables to search

// ═══════════════════════════════════════════════════════════════
// MAIN FUNCTIONS
// ═══════════════════════════════════════════════════════════════

// FUNCTION 1: Load search configuration (which tables to search)
async function loadSearchConfig() {
    if (searchConfigCache) {
        return searchConfigCache; // Use cached version if available
    }
    
    try {
        const { data, error } = await supabaseClient
            .from('system_search_config_20260129')
            .select('*')
            .eq('enabled', true)
            .order('priority');
        
        if (error) {
            console.error('❌ Error loading search config:', error);
            return [];
        }
        
        console.log(`✅ Loaded ${data.length} searchable tables from search_config`);
        searchConfigCache = data;
        return data;
    } catch (err) {
        console.error('❌ Failed to load search config:', err);
        return [];
    }
}

// FUNCTION 2: Search multiple queries across all configured tables
async function searchMultipleQueries(queries) {
    
    const searchConfig = await loadSearchConfig();
    
    if (!searchConfig || searchConfig.length === 0) {
        console.error('❌ No search configuration found!');
        return { formulas: [], acupoints: [], images: [] };
    }
    
    const allResults = [];
    let totalResults = 0;
    
    // Loop through each table in config
    for (const tableConfig of searchConfig) {
        if (isPaused) {
            break; // Stop if user paused search
        }
        
        // Loop through each query
        for (const query of queries) {
            try {
                let searchFields = tableConfig.search_fields;
                
                // Parse search fields (can be JSON or comma-separated string)
                if (typeof searchFields === 'string') {
                    try {
                        searchFields = JSON.parse(searchFields);
                    } catch (e) {
                        searchFields = searchFields.split(',').map(f => f.trim());
                    }
                }
                
                if (!Array.isArray(searchFields)) {
                    console.warn(`  ⚠️ Invalid search_fields for ${tableConfig.table_name}:`, searchFields);
                    continue;
                }
                
                if (searchFields.length === 0) {
                    console.warn(`  ⚠️ No search fields configured for ${tableConfig.table_name}`);
                    continue;
                }
                
                let tableResults = [];
                
                // Search each field in the table
                for (const field of searchFields) {
                    try {
                        const { data, error } = await supabaseClient
                            .from(tableConfig.table_name)
                            .select('*')
                            .ilike(field, `%${query}%`) // Case-insensitive search
                            .limit(20); // Max 20 results per field
                        
                        if (error) {
                            console.warn(`    ⚠️ Field "${field}" search failed:`, error.message);
                            continue; // Skip this field, try next one
                        }
                        
                        if (data && data.length > 0) {
                            console.log(`    ✅ Found ${data.length} in field "${field}"`);
                            tableResults.push(...data);
                        }
                    } catch (fieldError) {
                        console.warn(`    ⚠️ Exception searching field "${field}":`, fieldError.message);
                        continue;
                    }
                }
                
                // Remove duplicates (same ID in same table)
                const uniqueResults = Array.from(
                    new Map(tableResults.map(item => [item.id, item])).values()
                );
                
                if (uniqueResults.length > 0) {
                    console.log(`  ✅ Total ${uniqueResults.length} unique results in ${tableConfig.table_name}`);
                    
                    // Add metadata to each result
                    const resultsWithMeta = uniqueResults.map(row => ({
                        ...row,
                        _source_table: tableConfig.table_name,
                        _source_description: tableConfig.description,
                        _search_query: query
                    }));
                    
                    allResults.push(...resultsWithMeta);
                    totalResults += uniqueResults.length;
                }
                
            } catch (err) {
                console.error(`  ❌ Exception searching ${tableConfig.table_name}:`, err);
            }
        }
    }
    
    // Remove duplicates across all tables
    const seen = new Set();
    const uniqueResults = allResults.filter(result => {
        const key = `${result._source_table}_${result.id}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
    
    console.log(`\n✅ SEARCH COMPLETE! Total: ${uniqueResults.length} unique results`);
    
    // Organize results by type
    return {
        allResults: uniqueResults,
        totalResults: uniqueResults.length,
        formulas: uniqueResults.filter(r => r._source_table === 'tcm_formulas'),
        acupoints: uniqueResults
            .filter(r => r._source_table.includes('acupuncture') && r._source_table !== 'reference_rag_body_images_20260129')
            .map(point => ({
                code: point.point_code || point.point_number || point.code || 'N/A',
                english_name: point.english_name || point.point_name_eng || point.name_en || 'N/A',
                body_part: point.body_part || 'N/A',
                meridian: point.meridian || point.channel || 'N/A'
            })),
        images: uniqueResults.filter(r => r._source_table === 'reference_rag_body_images_20260129').map(img => ({
            id: img.id,
            body_part: img.body_part_hebrew || img.body_part,
            body_part_en: img.body_part,
            storage_url: img.image_url,
            filename: img.body_part,
            acupoint_codes: img.acupoint_codes || []
        }))
    };
}

// FUNCTION 3: Perform multi-query search (main search button)
async function performMultiQuery() {
    if (isPaused) {
        alert('החיפוש מושהה. לחץ "המשך" כדי להמשיך.');
        return;
    }
    
    // Collect all queries from 4 search boxes
    currentQueries = [];
    for (let i = 1; i <= 4; i++) {
        const val = document.getElementById(`searchInput${i}`).value.trim();
        if (val) currentQueries.push(val);
    }

    if (currentQueries.length === 0) {
        alert('נא להזין לפחות שאלה אחת');
        return;
    }

    totalQueries++;
    
    isSearching = true;
    startQueryTimer();
    
    // Show pause/stop buttons
    document.getElementById('pauseSearchBtn').classList.remove('hidden');
    document.getElementById('stopSearchBtn').classList.remove('hidden');
    document.getElementById('continueSearchBtn').classList.add('hidden');
    
    document.getElementById('tokenCount').style.animation = 'pulse 1s infinite';
    
    document.getElementById('pauseButton').classList.remove('hidden');
    isPaused = false;

    // Display active queries
    document.getElementById('activeQueries').innerHTML = `
        <div class="p-4 bg-blue-50 border-2 border-blue-300 rounded-xl">
            <h4 class="font-bold text-blue-800 mb-2 text-right">🔍 שאלות פעילות:</h4>
            <ul class="list-disc list-inside space-y-1 text-right">
                ${currentQueries.map(q => `<li class="text-blue-700">${q}</li>`).join('')}
            </ul>
        </div>
    `;

    const results = document.getElementById('searchResults');
    results.innerHTML = '<div class="text-center p-8"><div class="animate-spin text-6xl">🔄</div><p class="mt-4 text-lg">מחפש במאגר RAG...</p></div>';

    try {
        searchAbortController = new AbortController();
        
        const allResults = await searchMultipleQueries(currentQueries);
        
        if (isPaused) {
            results.innerHTML = '<div class="text-center p-8 text-orange-600"><h3 class="text-2xl font-bold">⏸️ חיפוש מושהה</h3><p>לחץ "המשך" כדי להמשיך</p></div>';
            return;
        }
        
        const hasResults = (allResults.totalResults && allResults.totalResults > 0) || 
                           (allResults.formulas && allResults.formulas.length > 0) || 
                           (allResults.acupoints && allResults.acupoints.length > 0);
        
        if (hasResults) {
            successfulQueries++;
            
            if (allResults.totalResults > 0 && allResults.allResults) {
                const uniqueTables = [...new Set(allResults.allResults.map(r => r._source_table))];
                
                highlightUsedCSVs(uniqueTables);
                
                const successMsg = document.createElement('div');
                successMsg.className = 'bg-green-50 p-4 rounded-lg border-2 border-green-200 mb-4 text-right';
                successMsg.innerHTML = `
                    <p class="text-green-800 font-bold text-lg" dir="rtl">
                        ✅ נמצאו ${allResults.totalResults} תוצאות מ-${uniqueTables.length} טבלאות!
                    </p>
                    <p class="text-green-600 text-sm mt-1" dir="rtl">
                        טבלאות: ${uniqueTables.join(', ')}
                    </p>
                `;
                results.appendChild(successMsg);
            }
            
            await displaySearchResults(allResults);
            document.getElementById('shareButtons').classList.remove('hidden');
            document.getElementById('reportOptions').classList.remove('hidden');
            document.getElementById('fallbackBrowser').classList.add('hidden');
        } else {
            await triggerFallbackSearch(currentQueries);
        }

        document.getElementById('tokenCount').style.animation = '';
        document.getElementById('pauseButton').classList.add('hidden');
        
        isSearching = false;
        stopQueryTimer();
        document.getElementById('pauseSearchBtn').classList.add('hidden');
        document.getElementById('continueSearchBtn').classList.add('hidden');
        document.getElementById('stopSearchBtn').classList.add('hidden');

    } catch (error) {
        console.error('Search error:', error);
        
        if (error.name === 'AbortError') {
            results.innerHTML = '<div class="text-center p-8 text-orange-600"><h3 class="text-2xl font-bold">⏸️ חיפוש מושהה</h3></div>';
        } else {
            results.innerHTML = `
                <div class="bg-red-50 p-6 rounded-xl border-2 border-red-200 text-right">
                    <h4 class="text-xl font-bold text-red-800 mb-2">⚠️ שגיאת חיפוש</h4>
                    <p class="text-red-600">${error.message}</p>
                </div>
            `;
        }
        
        document.getElementById('tokenCount').style.animation = '';
        document.getElementById('pauseButton').classList.add('hidden');
        
        isSearching = false;
        stopQueryTimer();
        document.getElementById('pauseSearchBtn').classList.add('hidden');
        document.getElementById('continueSearchBtn').classList.add('hidden');
        document.getElementById('stopSearchBtn').classList.add('hidden');
    }
}

// ═══════════════════════════════════════════════════════════════
// MAKE FUNCTIONS AVAILABLE TO HTML
// ═══════════════════════════════════════════════════════════════

window.loadSearchConfig = loadSearchConfig;
window.searchMultipleQueries = searchMultipleQueries;
window.performMultiQuery = performMultiQuery;

console.log('✅ Search-Engine module loaded successfully!');

// ═══════════════════════════════════════════════════════════════
// END OF MODULE
// ═══════════════════════════════════════════════════════════════
