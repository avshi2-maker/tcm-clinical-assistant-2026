/**
 * TCM BODY IMAGE INTEGRATION - VERSION 5
 * FIX: Reads queries directly from input boxes!
 */

console.log('🖼️ Body Image Integration V5 loading...');

// ═══════════════════════════════════════════════════════════════
// STORE QUERIES OURSELVES!
// ═══════════════════════════════════════════════════════════════
let savedQueries = [];

const BASE_URL = 'https://iqfglrwjemogoycbzltt.supabase.co/storage/v1/object/public/tcm-body-images/body-parts/';

const BODY_IMAGES = [
    { id: 0, file: 'front_full%20body.png', he: 'גוף מלא - קדמי' },
    { id: 1, file: 'back_body.png', he: 'גוף מלא - אחורי' },
    { id: 2, file: 'face_front.png', he: 'פנים' },
    { id: 3, file: 'side_head.png', he: 'ראש - צד' },
    { id: 4, file: 'ear.png', he: 'אוזן' },
    { id: 5, file: 'tounge.png', he: 'לשון' },
    { id: 6, file: 'arm_inner.png', he: 'זרוע פנימית' },
    { id: 7, file: 'outer_arm.png', he: 'זרוע חיצונית' },
    { id: 8, file: 'hand_dorsum.png', he: 'גב כף יד' },
    { id: 9, file: 'hand_inner%20palmar.png', he: 'כף יד' },
    { id: 10, file: 'leg_front.png', he: 'רגל קדמית' },
    { id: 11, file: 'inner_leg.png', he: 'רגל פנימית' },
    { id: 12, file: 'leg_outer.png', he: 'רגל חיצונית' },
    { id: 13, file: 'foot_left.png', he: 'כף רגל צד' },
    { id: 14, file: 'top_foot.png', he: 'כף רגל מלמעלה' },
    { id: 15, file: 'body_baby.png', he: 'תינוק' },
    { id: 16, file: 'chield_body%206-8%20years.png', he: 'ילד 6-8' }
];

const SYMPTOM_TO_IMAGES = {
    'ראש': [2, 3], 'כאב ראש': [2, 3], 'מיגרנה': [2, 3],
    'סחרחורת': [2, 3, 4], 'פנים': [2], 'עין': [2], 'עיניים': [2],
    'אוזן': [4], 'שמיעה': [4], 'טינטון': [4], 'לשון': [5],
    'צוואר': [1, 3], 'עורף': [1, 3],
    'בטן': [0], 'קיבה': [0], 'עיכול': [0], 'בחילה': [0, 5],
    'גב': [1], 'כאב גב': [1], 'עמוד שדרה': [1],
    'חזה': [0], 'לב': [0], 'ריאות': [0, 1], 'כליות': [1], 'כבד': [0],
    'יד': [6, 7, 8, 9], 'ידיים': [6, 7, 8, 9], 'זרוע': [6, 7],
    'כתף': [0, 1, 7], 'מרפק': [6, 7], 'כף יד': [8, 9],
    'רגל': [10, 11, 12], 'רגליים': [10, 11, 12], 'ברך': [10, 12],
    'ירך': [10, 11], 'קרסול': [13, 14], 'כף רגל': [13, 14],
    'ילד': [16], 'ילדים': [16], 'תינוק': [15],
    'עייפות': [0, 1], 'שינה': [2, 3], 'חרדה': [0, 2], 'מתח': [1, 3],
    'וסת': [0], 'מחזור': [0], 'הריון': [0, 15],
    'אלרגיה': [0, 2], 'אלרגיות': [0, 2], 'אסתמה': [0],
    'סרטן': [0, 1], 'כאב': [0, 1], 'כאבים': [0, 1],
    'דיקור': [0, 1, 6, 10], 'נקודות': [0, 1, 6, 10], 'נקודה': [0, 1, 6, 10],
    'דופק': [6, 9], 'יין': [0, 5], 'יאנג': [1],
    'מתכת': [0, 6], 'עץ': [0, 11], 'אש': [0, 2], 'מים': [0, 11], 'אדמה': [0, 10],
    'חודש': [0, 1], 'יינג': [0, 1], 'בעיות': [0, 1]
};

const ACUPOINT_TO_IMAGE = {
    'GV20': 2, 'GB20': 3, 'ST8': 2, 'TW17': 4, 'SI19': 4,
    'LU7': 6, 'PC6': 6, 'HT7': 6, 'LI4': 8, 'LI11': 7,
    'ST36': 10, 'SP6': 11, 'KI3': 11, 'LV3': 14,
    'GB34': 12, 'BL40': 12, 'BL60': 13,
    'BL13': 1, 'BL20': 1, 'BL23': 1, 'GV4': 1,
    'CV4': 0, 'CV6': 0, 'CV12': 0, 'ST25': 0
};

// GET QUERIES FROM INPUT BOXES!
function getQueriesFromInputs() {
    const queries = [];
    for (let i = 1; i <= 4; i++) {
        const input = document.getElementById('searchInput' + i);
        if (input && input.value && input.value.trim()) {
            queries.push(input.value.trim());
        }
    }
    console.log('📥 Queries from inputs:', queries);
    return queries;
}

function findImagesFromKeywords(queries) {
    const imageIds = new Set();
    const queryText = queries.join(' ').toLowerCase();
    
    for (const [keyword, ids] of Object.entries(SYMPTOM_TO_IMAGES)) {
        if (queryText.includes(keyword.toLowerCase())) {
            ids.forEach(id => imageIds.add(id));
            console.log('   🔍 "' + keyword + '" → [' + ids.join(',') + ']');
        }
    }
    return Array.from(imageIds);
}

function getBodyImages(queries) {
    console.log('🖼️ getBodyImages:', queries);
    if (!queries || queries.length === 0) return { images: [], count: 0 };
    
    const imageIds = findImagesFromKeywords(queries);
    const uniqueIds = [...new Set(imageIds)].slice(0, 5);
    const images = uniqueIds.map(id => BODY_IMAGES[id]).filter(Boolean);
    
    console.log('✅ Found ' + images.length + ' images');
    return { images: images, count: images.length };
}

function createHTML(data) {
    if (!data || data.count === 0) return '';
    
    let imgs = '';
    data.images.forEach(function(img) {
        imgs += '<div style="display:inline-block;margin:10px;text-align:center;cursor:pointer;" onclick="BodyImages.show(' + img.id + ')">' +
            '<img src="' + BASE_URL + img.file + '" alt="' + img.he + '" ' +
            'style="width:100px;height:100px;object-fit:contain;border-radius:12px;border:3px solid #3b82f6;background:white;padding:4px;" ' +
            'onerror="this.parentElement.style.display=\'none\'">' +
            '<div style="font-size:11px;color:#1e40af;margin-top:5px;font-weight:bold;">' + img.he + '</div>' +
            '</div>';
    });
    
    return '<div id="body-images-section" style="background:linear-gradient(135deg,#eff6ff,#dbeafe);border:3px solid #3b82f6;border-radius:16px;padding:20px;margin:20px 0;text-align:center;direction:rtl;">' +
        '<h3 style="color:#1e40af;font-size:20px;font-weight:bold;margin-bottom:15px;">📍 מיקום נקודות על הגוף</h3>' +
        '<div style="display:flex;flex-wrap:wrap;justify-content:center;">' + imgs + '</div>' +
        '<button onclick="BodyImages.show()" style="margin-top:15px;background:#3b82f6;color:white;padding:10px 20px;border:none;border-radius:10px;cursor:pointer;font-weight:bold;">📷 גלריית גוף מלאה</button>' +
        '</div>';
}

function insertBodyImages() {
    console.log('🔄 insertBodyImages() - savedQueries:', savedQueries);
    
    var existing = document.getElementById('body-images-section');
    if (existing) existing.remove();
    
    if (!savedQueries || savedQueries.length === 0) {
        console.log('⚠️ No savedQueries!');
        return;
    }
    
    var data = getBodyImages(savedQueries);
    if (data.count === 0) {
        console.log('⚠️ No matching images');
        return;
    }
    
    var html = createHTML(data);
    var container = document.getElementById('searchResults');
    if (!container) {
        console.log('⚠️ searchResults not found');
        return;
    }
    
    var successBox = container.querySelector('.bg-green-50');
    if (successBox) {
        successBox.insertAdjacentHTML('afterend', html);
    } else {
        container.insertAdjacentHTML('afterbegin', html);
    }
    
    console.log('✅ Body images inserted!');
}

// OBSERVER
var observer = null;
var attempts = 0;

function startWatching() {
    console.log('👁️ Starting observer...');
    attempts = 0;
    if (observer) observer.disconnect();
    
    var container = document.getElementById('searchResults');
    if (!container) return;
    
    observer = new MutationObserver(function() {
        var hasResults = container.querySelector('.bg-green-50') || container.textContent.includes('תוצאות');
        var hasSpinner = container.querySelector('.animate-spin');
        var hasImages = document.getElementById('body-images-section');
        
        if (hasResults && !hasSpinner && !hasImages && attempts < 3) {
            attempts++;
            console.log('👁️ Results detected! Attempt ' + attempts);
            setTimeout(insertBodyImages, 300);
        }
    });
    
    observer.observe(container, { childList: true, subtree: true });
}

// HOOK performMultiQuery
var originalPerformMultiQuery = window.performMultiQuery;

window.performMultiQuery = async function() {
    console.log('🔄 performMultiQuery intercepted');
    
    // ★ CAPTURE QUERIES FIRST! ★
    savedQueries = getQueriesFromInputs();
    console.log('💾 SAVED:', savedQueries);
    
    startWatching();
    
    if (originalPerformMultiQuery) {
        await originalPerformMultiQuery();
    }
    
    setTimeout(function() {
        if (!document.getElementById('body-images-section') && savedQueries.length > 0) {
            console.log('🔄 Final attempt...');
            insertBodyImages();
        }
        if (observer) observer.disconnect();
    }, 2000);
};

// Manual trigger
window.addBodyImagesNow = function() {
    savedQueries = getQueriesFromInputs();
    insertBodyImages();
};

window.BodyImageIntegration = { insertBodyImages: insertBodyImages, getQueriesFromInputs: getQueriesFromInputs };

console.log('✅ Body Image Integration V5 loaded!');
console.log('📖 Captures queries from input boxes directly!');
