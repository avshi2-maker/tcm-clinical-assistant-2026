/**
 * TCM Export Module - FIXED VERSION
 * Now properly prints AI Search Reports!
 * 
 * Usage: ExportModule.print(), ExportModule.email(), ExportModule.whatsapp()
 * For AI Reports: ExportModule.printAIReport()
 */
(function() {
    
    // Configuration
    const CONFIG = {
        clinicName: 'מרפאת TCM - רפואה סינית',
        clinicPhone: '052-1234567',
        clinicEmail: 'clinic@tcm.co.il',
        clinicWhatsApp: '972521234567'
    };
    
    // Inject print styles - NOW INCLUDES AI REPORTS!
    function injectPrintStyles() {
        // Remove old styles first
        const oldStyle = document.getElementById('export-print-styles');
        if (oldStyle) oldStyle.remove();
        
        const style = document.createElement('style');
        style.id = 'export-print-styles';
        style.textContent = `
            /* ═══════════════════════════════════════════════════════════════
               TCM EXPORT MODULE - PRINT STYLES
               Supports: Yin-Yang Results + AI Search Reports
               ═══════════════════════════════════════════════════════════════ */
            
            @media print {
                /* ═══════════════════════════════════════════════════════
                   HIDE EVERYTHING BY DEFAULT
                   ═══════════════════════════════════════════════════════ */
                
                body > *:not(.print-container):not(#print-report-wrapper) {
                    display: none !important;
                }
                
                /* Hide controls and navigation */
                .no-print, 
                .left-panel, 
                .right-panel,
                nav,
                .sidebar,
                header,
                footer,
                button,
                input,
                .export-buttons,
                #export-modal,
                #shareButtons,
                #reportOptions,
                #activeQueries,
                .golden-clock,
                .metrics-box,
                .query-box,
                .pause-button,
                .run-query-button,
                #fallbackBrowser {
                    display: none !important;
                }
                
                /* ═══════════════════════════════════════════════════════
                   SHOW PRINT WRAPPER (created dynamically)
                   ═══════════════════════════════════════════════════════ */
                
                #print-report-wrapper {
                    display: block !important;
                    position: static !important;
                    overflow: visible !important;
                    height: auto !important;
                    width: 100% !important;
                    padding: 0 !important;
                    margin: 0 !important;
                }
                
                /* Show print elements */
                .print-only { 
                    display: block !important; 
                }
                
                /* ═══════════════════════════════════════════════════════
                   YIN-YANG MODULE PRINTING
                   ═══════════════════════════════════════════════════════ */
                
                body.print-yinyang #yinyang-module {
                    display: block !important;
                    position: static !important;
                    overflow: visible !important;
                    height: auto !important;
                    background: white !important;
                }
                
                body.print-yinyang #results {
                    display: block !important;
                    position: static !important;
                    overflow: visible !important;
                    height: auto !important;
                    max-height: none !important;
                }
                
                body.print-yinyang #yinyang-module > div:first-child {
                    display: none !important;
                }
                
                /* ═══════════════════════════════════════════════════════
                   PAGE LAYOUT
                   ═══════════════════════════════════════════════════════ */
                
                html, body {
                    overflow: visible !important;
                    height: auto !important;
                    width: auto !important;
                    margin: 0 !important;
                    padding: 0 !important;
                    background: white !important;
                    font-size: 11pt !important;
                }
                
                /* All containers flow naturally */
                .report-container,
                .main-content,
                .prose,
                [class*="container"] {
                    position: static !important;
                    overflow: visible !important;
                    height: auto !important;
                    max-height: none !important;
                    width: 100% !important;
                    transform: none !important;
                    float: none !important;
                }
                
                /* ═══════════════════════════════════════════════════════
                   PAGE BREAKS
                   ═══════════════════════════════════════════════════════ */
                
                .page-break { 
                    page-break-before: always !important; 
                }
                
                .no-page-break,
                section,
                .card,
                .box,
                .bg-gradient-to-r,
                [class*="rounded-xl"],
                [class*="border-2"] {
                    page-break-inside: avoid !important;
                    break-inside: avoid !important;
                    margin-bottom: 12px !important;
                }
                
                h1, h2, h3, h4, h5, h6 {
                    page-break-after: avoid !important;
                }
                
                /* ═══════════════════════════════════════════════════════
                   COLORS & BACKGROUNDS
                   ═══════════════════════════════════════════════════════ */
                
                * {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                    color-adjust: exact !important;
                }
                
                /* Keep gradient backgrounds */
                .bg-gradient-to-r {
                    background: #f0f9ff !important;
                    border: 2px solid #3b82f6 !important;
                }
                
                .bg-green-50 {
                    background: #f0fdf4 !important;
                }
                
                .bg-purple-50 {
                    background: #faf5ff !important;
                }
                
                .bg-yellow-50 {
                    background: #fefce8 !important;
                }
                
                /* ═══════════════════════════════════════════════════════
                   IMAGES
                   ═══════════════════════════════════════════════════════ */
                
                img {
                    max-width: 100% !important;
                    max-height: 200px !important;
                    page-break-inside: avoid !important;
                    object-fit: contain !important;
                }
                
                .grid {
                    display: grid !important;
                    grid-template-columns: repeat(3, 1fr) !important;
                    gap: 10px !important;
                }
                
                /* ═══════════════════════════════════════════════════════
                   PAGE SETTINGS
                   ═══════════════════════════════════════════════════════ */
                
                @page {
                    size: A4;
                    margin: 15mm;
                }
                
                /* ═══════════════════════════════════════════════════════
                   PRINT HEADER/FOOTER
                   ═══════════════════════════════════════════════════════ */
                
                .print-header {
                    text-align: center;
                    margin-bottom: 20px;
                    padding-bottom: 15px;
                    border-bottom: 3px solid #3b82f6;
                }
                
                .print-header h1 {
                    font-size: 22pt;
                    color: #1e40af;
                    margin: 0;
                }
                
                .print-header .date {
                    font-size: 10pt;
                    color: #666;
                    margin-top: 5px;
                }
                
                .print-footer {
                    text-align: center;
                    margin-top: 30px;
                    padding-top: 15px;
                    border-top: 1px solid #ccc;
                    font-size: 9pt;
                    color: #666;
                }
            }
            
            /* ═══════════════════════════════════════════════════════
               EXPORT MODAL STYLES (not print)
               ═══════════════════════════════════════════════════════ */
            
            #export-modal {
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,0.85);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            #export-modal .modal-content {
                background: white;
                border-radius: 20px;
                padding: 30px;
                max-width: 420px;
                width: 90%;
                direction: rtl;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            
            #export-modal h3 {
                font-size: 26px;
                font-weight: bold;
                margin-bottom: 25px;
                color: #1e293b;
            }
            
            #export-modal .export-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 12px;
                width: 100%;
                padding: 16px 24px;
                margin: 12px 0;
                border: none;
                border-radius: 12px;
                font-size: 17px;
                font-weight: bold;
                cursor: pointer;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            
            #export-modal .export-btn:hover {
                transform: scale(1.03);
                box-shadow: 0 6px 20px rgba(0,0,0,0.25);
            }
            
            #export-modal .btn-print {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
            }
            
            #export-modal .btn-pdf {
                background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
                color: white;
            }
            
            #export-modal .btn-email {
                background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
                color: white;
            }
            
            #export-modal .btn-whatsapp {
                background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
                color: white;
            }
            
            #export-modal .btn-close {
                background: #e5e7eb;
                color: #374151;
                margin-top: 20px;
            }
            
            #export-modal .btn-close:hover {
                background: #d1d5db;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Show export modal
    function showExportModal(options = {}) {
        const title = options.title || 'ייצוא דו"ח';
        const subject = options.subject || 'דו"ח TCM';
        
        // Remove existing modal
        const existing = document.getElementById('export-modal');
        if (existing) existing.remove();
        
        const modal = document.createElement('div');
        modal.id = 'export-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h3>📤 ${title}</h3>
                
                <button class="export-btn btn-print" onclick="ExportModule.printAIReport()">
                    <span>🖨️</span>
                    <span>הדפס דו"ח AI</span>
                </button>
                
                <button class="export-btn btn-pdf" onclick="ExportModule.printAsPDF()">
                    <span>📄</span>
                    <span>שמור כ-PDF</span>
                </button>
                
                <button class="export-btn btn-email" onclick="ExportModule.email('${subject}')">
                    <span>📧</span>
                    <span>שלח במייל</span>
                </button>
                
                <button class="export-btn btn-whatsapp" onclick="ExportModule.whatsapp('${subject}')">
                    <span>💬</span>
                    <span>שלח בוואטסאפ</span>
                </button>
                
                <button class="export-btn btn-close" onclick="ExportModule.closeModal()">
                    ✕ סגור
                </button>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) ExportModule.closeModal();
        });
    }
    
    // Close modal
    function closeModal() {
        const modal = document.getElementById('export-modal');
        if (modal) modal.remove();
    }
    
    // ═══════════════════════════════════════════════════════════════
    // 🆕 NEW: Print AI Report - Creates printable wrapper
    // ═══════════════════════════════════════════════════════════════
    function printAIReport() {
        closeModal();
        
        // Get the search results content
        const searchResults = document.getElementById('searchResults');
        if (!searchResults || !searchResults.innerHTML.trim()) {
            alert('אין דו"ח להדפסה. הרץ חיפוש קודם.');
            return;
        }
        
        // Get queries if available
        let queriesText = '';
        if (typeof currentQueries !== 'undefined' && currentQueries.length > 0) {
            queriesText = currentQueries.join(' | ');
        }
        
        // Create print wrapper
        const wrapper = document.createElement('div');
        wrapper.id = 'print-report-wrapper';
        wrapper.innerHTML = `
            <div class="print-header">
                <h1>🏥 דו"ח אבחון TCM</h1>
                <div class="date">
                    תאריך: ${new Date().toLocaleDateString('he-IL')} | 
                    שעה: ${new Date().toLocaleTimeString('he-IL')}
                </div>
                ${queriesText ? `<div style="margin-top:10px;font-size:12pt;color:#4b5563;">שאילתות: ${queriesText}</div>` : ''}
            </div>
            
            <div dir="rtl" style="text-align:right;">
                ${searchResults.innerHTML}
            </div>
            
            <div class="print-footer">
                <p>${CONFIG.clinicName}</p>
                <p>הופק ע"י TCM Clinical Assistant</p>
            </div>
        `;
        
        document.body.appendChild(wrapper);
        
        // Print
        setTimeout(() => {
            window.print();
            
            // Cleanup after print
            setTimeout(() => {
                wrapper.remove();
            }, 1000);
        }, 200);
    }
    
    // Original print (for Yin-Yang module)
    function print() {
        closeModal();
        
        // Check if yinyang module is open
        const yinyangModule = document.getElementById('yinyang-module');
        const resultsDiv = document.getElementById('results');
        
        if (yinyangModule && yinyangModule.style.display !== 'none' && 
            resultsDiv && resultsDiv.style.display !== 'none') {
            // Print Yin-Yang results
            document.body.classList.add('print-yinyang');
            
            const originalStyles = {
                position: yinyangModule.style.position,
                overflow: yinyangModule.style.overflow,
                height: yinyangModule.style.height
            };
            
            yinyangModule.style.position = 'static';
            yinyangModule.style.overflow = 'visible';
            yinyangModule.style.height = 'auto';
            
            setTimeout(() => {
                window.print();
                
                setTimeout(() => {
                    document.body.classList.remove('print-yinyang');
                    yinyangModule.style.position = originalStyles.position;
                    yinyangModule.style.overflow = originalStyles.overflow;
                    yinyangModule.style.height = originalStyles.height;
                }, 1000);
            }, 200);
        } else {
            // Try AI report
            printAIReport();
        }
    }
    
    // Print as PDF
    function printAsPDF() {
        closeModal();
        alert('💡 בחלון ההדפסה:\n\n1. בחר "שמור כ-PDF" בתור היעד\n2. לחץ "שמור"\n\nהקובץ יישמר למחשב שלך!');
        printAIReport();
    }
    
    // Email function
    function email(subject = 'דו"ח TCM') {
        closeModal();
        
        const body = getReportText();
        const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        
        window.open(mailtoUrl, '_blank');
    }
    
    // WhatsApp function
    function whatsapp(subject = 'דו"ח TCM') {
        closeModal();
        
        const body = getReportText();
        const text = `*${subject}*\n\n${body}\n\n---\n${CONFIG.clinicName}`;
        const waUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
        
        window.open(waUrl, '_blank');
    }
    
    // WhatsApp to specific number
    function whatsappTo(phone, subject = 'דו"ח TCM') {
        closeModal();
        
        const body = getReportText();
        const text = `*${subject}*\n\n${body}`;
        const waUrl = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
        
        window.open(waUrl, '_blank');
    }
    
    // ═══════════════════════════════════════════════════════════════
    // Get report text for sharing
    // ═══════════════════════════════════════════════════════════════
    function getReportText() {
        let text = '';
        
        // Try AI search results first
        const searchResults = document.getElementById('searchResults');
        if (searchResults && searchResults.innerHTML.trim()) {
            // Get just the text content
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = searchResults.innerHTML;
            
            // Remove images and complex elements for text export
            tempDiv.querySelectorAll('img, .grid').forEach(el => el.remove());
            
            text = tempDiv.innerText || tempDiv.textContent;
            text = text.substring(0, 2000); // Limit for WhatsApp
            
            // Add queries if available
            if (typeof currentQueries !== 'undefined' && currentQueries.length > 0) {
                text = `שאילתות: ${currentQueries.join(' | ')}\n\n${text}`;
            }
        }
        
        // Try Yin-Yang results
        if (!text) {
            const pattern = document.getElementById('primary-pattern-badge')?.textContent || '';
            const explanation = document.getElementById('patient-explanation')?.textContent || '';
            if (pattern || explanation) {
                text = `דפוס: ${pattern}\n\n${explanation}`;
            }
        }
        
        // Fallback
        if (!text) {
            text = 'דו"ח TCM Clinical Assistant';
        }
        
        // Add timestamp
        const now = new Date();
        const timestamp = now.toLocaleDateString('he-IL') + ' ' + now.toLocaleTimeString('he-IL');
        text += `\n\nתאריך: ${timestamp}`;
        
        return text;
    }
    
    // Update clinic config
    function setConfig(newConfig) {
        Object.assign(CONFIG, newConfig);
    }
    
    // Initialize
    injectPrintStyles();
    
    // ═══════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════
    window.ExportModule = {
        show: showExportModal,
        showModal: showExportModal,
        closeModal,
        print,
        printAIReport,        // 🆕 NEW - prints AI search results
        printAsPDF,
        email,
        whatsapp,
        whatsappTo,
        setConfig,
        getConfig: () => CONFIG,
        getReportText         // 🆕 Useful for custom exports
    };
    
    console.log('✅ ExportModule FIXED loaded! Now prints AI reports properly!');
    console.log('📌 Use ExportModule.printAIReport() for AI search results');
    
})();
