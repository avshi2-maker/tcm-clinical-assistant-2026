// ═══════════════════════════════════════════════════════════════
// 🏥 CLINICAL MODULES - RIGHT PANEL (3 MODULES)
// ═══════════════════════════════════════════════════════════════
// Module 1: DR Roni Points (341 acupuncture points)
// Module 2: Zang-Fu Syndromes (11 syndromes)
// Module 3: Clinical Symptoms (52 diagnostic questions)
//
// Loaded from: Supabase Storage
// Called by: index.html
// Dependencies: supabaseClient (global)
// ═══════════════════════════════════════════════════════════════

(function() {
    'use strict';
    
    console.log('🏥 Loading Clinical Modules...');
    
    // ═══════════════════════════════════════════════════════════════
    // MODULE STATE
    // ═══════════════════════════════════════════════════════════════
    
    let drRoniData = null;
    let zangfuData = null;
    let symptomsData = null;
    let selectedClinicalItems = new Set();
    
    // ═══════════════════════════════════════════════════════════════
    // MODULE 1: DR RONI ACUPUNCTURE POINTS (341 POINTS)
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Toggle visibility of DR Roni Points dropdown
     */
    window.toggleDrRoniPoints = function() {
        const dropdown = document.getElementById('drRoniDropdown');
        const toggle = document.getElementById('drRoniToggle');
        
        if (!dropdown || !toggle) {
            console.error('❌ DR Roni elements not found');
            return;
        }
        
        if (dropdown.classList.contains('hidden')) {
            dropdown.classList.remove('hidden');
            toggle.textContent = '🔼';
            
            // Load data on first open
            if (!drRoniData) {
                console.log('📥 Loading DR Roni points...');
                loadDrRoniPoints();
            }
        } else {
            dropdown.classList.add('hidden');
            toggle.textContent = '🔽';
        }
    };
    
    /**
     * Load DR Roni acupuncture points from database
     */
    async function loadDrRoniPoints() {
        try {
            const { data, error } = await supabaseClient
                .from('treatment_rag_acupoints_gallery_20260129')
                .select('point_code, english_name_hebrew')
                .order('point_code')
                .limit(50); // Load first 50 for performance
            
            if (error) {
                console.error('❌ Error loading DR Roni points:', error);
                document.getElementById('drRoniDropdown').innerHTML = 
                    '<div class="text-white text-center text-xs py-2">❌ שגיאה בטעינה</div>';
                return;
            }
            
            drRoniData = data;
            console.log(`✅ Loaded ${data.length} DR Roni points`);
            displayDrRoniPoints(data);
            
        } catch (err) {
            console.error('❌ Exception loading DR Roni:', err);
            document.getElementById('drRoniDropdown').innerHTML = 
                '<div class="text-white text-center text-xs py-2">❌ שגיאה</div>';
        }
    }
    
    /**
     * Display DR Roni points in dropdown
     */
    function displayDrRoniPoints(points) {
        const container = document.getElementById('drRoniDropdown');
        
        if (!container) {
            console.error('❌ DR Roni dropdown not found');
            return;
        }
        
        if (!points || points.length === 0) {
            container.innerHTML = '<div class="text-white text-center text-xs py-2">אין נתונים</div>';
            return;
        }
        
        let html = '';
        points.forEach(point => {
            const id = `drroni-${point.point_code}`;
            html += `
                <div class="clinical-item" 
                     id="${id}" 
                     onclick="window.selectClinicalItem('${point.point_code}', '${point.english_name_hebrew}', '${id}')">
                    <strong>${point.point_code}</strong> - ${point.english_name_hebrew}
                </div>
            `;
        });
        
        container.innerHTML = html;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // MODULE 2: ZANG-FU SYNDROMES (11 SYNDROMES)
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Toggle visibility of Zang-Fu Syndromes dropdown
     */
    window.toggleZangFuSyndromes = function() {
        const dropdown = document.getElementById('zangfuDropdown');
        const toggle = document.getElementById('zangfuToggle');
        
        if (!dropdown || !toggle) {
            console.error('❌ Zang-Fu elements not found');
            return;
        }
        
        if (dropdown.classList.contains('hidden')) {
            dropdown.classList.remove('hidden');
            toggle.textContent = '🔼';
            
            // Load data on first open
            if (!zangfuData) {
                console.log('📥 Loading Zang-Fu syndromes...');
                loadZangFuSyndromes();
            }
        } else {
            dropdown.classList.add('hidden');
            toggle.textContent = '🔽';
        }
    };
    
    /**
     * Load Zang-Fu syndromes from database
     */
    async function loadZangFuSyndromes() {
        try {
            const { data, error } = await supabaseClient
                .from('bible_rag_zangfu_syndromes_20260129')
                .select('id, name_he')
                .order('name_he');
            
            if (error) {
                console.error('❌ Error loading Zang-Fu syndromes:', error);
                document.getElementById('zangfuDropdown').innerHTML = 
                    '<div class="text-white text-center text-xs py-2">❌ שגיאה בטעינה</div>';
                return;
            }
            
            zangfuData = data;
            console.log(`✅ Loaded ${data.length} Zang-Fu syndromes`);
            displayZangFuSyndromes(data);
            
        } catch (err) {
            console.error('❌ Exception loading Zang-Fu:', err);
            document.getElementById('zangfuDropdown').innerHTML = 
                '<div class="text-white text-center text-xs py-2">❌ שגיאה</div>';
        }
    }
    
    /**
     * Display Zang-Fu syndromes in dropdown
     */
    function displayZangFuSyndromes(syndromes) {
        const container = document.getElementById('zangfuDropdown');
        
        if (!container) {
            console.error('❌ Zang-Fu dropdown not found');
            return;
        }
        
        if (!syndromes || syndromes.length === 0) {
            container.innerHTML = '<div class="text-white text-center text-xs py-2">אין נתונים</div>';
            return;
        }
        
        let html = '';
        syndromes.forEach(syndrome => {
            const id = `zangfu-${syndrome.id}`;
            html += `
                <div class="clinical-item" 
                     id="${id}" 
                     onclick="window.selectClinicalItem('${syndrome.id}', '${syndrome.name_he}', '${id}')">
                    <strong>${syndrome.id.substring(0, 8)}</strong> - ${syndrome.name_he}
                </div>
            `;
        });
        
        container.innerHTML = html;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // MODULE 3: CLINICAL SYMPTOMS (52 QUESTIONS)
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Toggle visibility of Clinical Symptoms dropdown
     */
    window.toggleClinicalSymptoms = function() {
        const dropdown = document.getElementById('clinicalDropdown');
        const toggle = document.getElementById('clinicalToggle');
        
        if (!dropdown || !toggle) {
            console.error('❌ Clinical symptoms elements not found');
            return;
        }
        
        if (dropdown.classList.contains('hidden')) {
            dropdown.classList.remove('hidden');
            toggle.textContent = '🔼';
            
            // Load data on first open
            if (!symptomsData) {
                console.log('📥 Loading clinical symptoms...');
                loadClinicalSymptoms();
            }
        } else {
            dropdown.classList.add('hidden');
            toggle.textContent = '🔽';
        }
    };
    
    /**
     * Load clinical symptoms from database
     */
    async function loadClinicalSymptoms() {
        try {
            const { data, error } = await supabaseClient
                .from('diagnostic_rag_yinyang_symptoms_20260129')
                .select('question_id, question_text_he, pattern_indication')
                .order('pattern_indication')
                .order('question_text_he');
            
            if (error) {
                console.error('❌ Error loading symptoms:', error);
                document.getElementById('clinicalDropdown').innerHTML = 
                    '<div class="text-white text-center text-xs py-2">❌ שגיאה בטעינה</div>';
                return;
            }
            
            symptomsData = data;
            console.log(`✅ Loaded ${data.length} clinical symptoms`);
            displayClinicalSymptoms(data);
            
        } catch (err) {
            console.error('❌ Exception loading symptoms:', err);
            document.getElementById('clinicalDropdown').innerHTML = 
                '<div class="text-white text-center text-xs py-2">❌ שגיאה</div>';
        }
    }
    
    /**
     * Display clinical symptoms in dropdown
     */
    function displayClinicalSymptoms(symptoms) {
        const container = document.getElementById('clinicalDropdown');
        
        if (!container) {
            console.error('❌ Clinical symptoms dropdown not found');
            return;
        }
        
        if (!symptoms || symptoms.length === 0) {
            container.innerHTML = '<div class="text-white text-center text-xs py-2">אין נתונים</div>';
            return;
        }
        
        let html = '';
        
        // Show first 30 only for performance
        symptoms.slice(0, 30).forEach(symptom => {
            const id = `symptom-${symptom.question_id}`;
            html += `
                <div class="clinical-item" 
                     id="${id}" 
                     onclick="window.selectClinicalItem('${symptom.question_id}', '${symptom.question_text_he}', '${id}')">
                    ${symptom.question_text_he}
                </div>
            `;
        });
        
        if (symptoms.length > 30) {
            html += `<div class="text-white text-center text-xs py-2 italic">ו-${symptoms.length - 30} עוד...</div>`;
        }
        
        container.innerHTML = html;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // SHARED UTILITY FUNCTIONS
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Select/deselect clinical item and add to query box
     */
    window.selectClinicalItem = function(code, text, elementId) {
        const element = document.getElementById(elementId);
        
        if (!element) {
            console.error('❌ Clinical item element not found:', elementId);
            return;
        }
        
        if (selectedClinicalItems.has(code)) {
            // Deselect
            selectedClinicalItems.delete(code);
            element.classList.remove('selected');
            removeFromQueryBox(text);
        } else {
            // Select
            selectedClinicalItems.add(code);
            element.classList.add('selected');
            addToQueryBox(text);
        }
    };
    
    /**
     * Add text to first available query box
     */
    function addToQueryBox(text) {
        const boxes = ['searchInput1', 'searchInput2', 'searchInput3'];
        
        for (let boxId of boxes) {
            const input = document.getElementById(boxId);
            
            if (input && input.value.trim() === '') {
                input.value = text;
                
                // Update box styling
                const box = document.getElementById(boxId.replace('searchInput', 'queryBox'));
                if (box) {
                    box.classList.add('filled');
                }
                
                console.log(`✅ Added to ${boxId}:`, text);
                return;
            }
        }
        
        // If all boxes full, append to first box
        const input = document.getElementById('searchInput1');
        if (input) {
            input.value += '\n' + text;
            console.log('✅ Appended to searchInput1');
        }
    }
    
    /**
     * Remove text from query boxes
     */
    function removeFromQueryBox(text) {
        const boxes = ['searchInput1', 'searchInput2', 'searchInput3'];
        
        for (let boxId of boxes) {
            const input = document.getElementById(boxId);
            
            if (input && input.value.includes(text)) {
                input.value = input.value.replace(text, '').trim();
                
                // Update box styling
                if (input.value === '') {
                    const box = document.getElementById(boxId.replace('searchInput', 'queryBox'));
                    if (box) {
                        box.classList.remove('filled');
                    }
                }
                
                console.log(`✅ Removed from ${boxId}`);
                return;
            }
        }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════════════
    
    console.log('✅ Clinical Modules loaded successfully');
    console.log('   📍 DR Roni Points (341)');
    console.log('   🫀 Zang-Fu Syndromes (11)');
    console.log('   🩺 Clinical Symptoms (52)');
    
})();
