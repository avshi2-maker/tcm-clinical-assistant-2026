// ═══════════════════════════════════════════════════════════════
// 🏗️ LAYOUT LOADER - IRONCLAD SYSTEM
// ═══════════════════════════════════════════════════════════════
// This script loads the page layout from Supabase Storage
// and injects it into the main container
//
// BENEFITS:
// - Change layout → Just edit page-layout.html in Supabase!
// - index.html NEVER needs to change
// - Professional separation of concerns
// - Easy to maintain and update
// ═══════════════════════════════════════════════════════════════

(function() {
    'use strict';
    
    console.log('🏗️ Ironclad Layout Loader starting...');
    
    const LAYOUT_URL = 'https://iqfglrwjemogoycbzltt.supabase.co/storage/v1/object/public/modules/page-layout.html';
    
    /**
     * Load and inject the page layout
     */
    async function loadPageLayout() {
        const container = document.getElementById('app-container');
        
        if (!container) {
            console.error('❌ #app-container not found! Cannot load layout.');
            return;
        }
        
        // Show loading message
        container.innerHTML = `
            <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
                <div class="text-center">
                    <div class="text-6xl mb-4">🏗️</div>
                    <h2 class="text-2xl font-bold text-gray-700 mb-2">טוען מערכת...</h2>
                    <p class="text-gray-500">Loading layout from Supabase...</p>
                    <div class="mt-4">
                        <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                    </div>
                </div>
            </div>
        `;
        
        try {
            console.log('📥 Fetching layout from:', LAYOUT_URL);
            
            const response = await fetch(LAYOUT_URL);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const layoutHTML = await response.text();
            
            console.log(`✅ Layout loaded (${layoutHTML.length} bytes)`);
            
            // Inject the layout
            container.innerHTML = layoutHTML;
            
            console.log('✅ Layout injected into page');
            console.log('🎉 Ironclad Layout System ready!');
            
            // Dispatch event so other scripts know layout is ready
            window.dispatchEvent(new CustomEvent('layoutReady'));
            
        } catch (error) {
            console.error('❌ Failed to load layout:', error);
            
            // Show error message
            container.innerHTML = `
                <div class="min-h-screen flex items-center justify-center bg-red-50">
                    <div class="text-center max-w-md p-8 bg-white rounded-xl shadow-lg">
                        <div class="text-6xl mb-4">❌</div>
                        <h2 class="text-2xl font-bold text-red-600 mb-2">שגיאה בטעינת המערכת</h2>
                        <p class="text-gray-700 mb-4">לא ניתן לטעון את עיצוב הדף</p>
                        <p class="text-sm text-gray-500 mb-4">${error.message}</p>
                        <button onclick="window.location.reload()" 
                                class="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600">
                            🔄 נסה שוב
                        </button>
                        <div class="mt-4 text-xs text-gray-400">
                            <p>Layout URL:</p>
                            <p class="break-all">${LAYOUT_URL}</p>
                        </div>
                    </div>
                </div>
            `;
        }
    }
    
    /**
     * Wait for DOM to be ready, then load layout
     */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadPageLayout);
    } else {
        // DOM already loaded
        loadPageLayout();
    }
    
})();

// ═══════════════════════════════════════════════════════════════
// USAGE NOTES:
// 
// This script expects:
// 1. A div with id="app-container" in index.html
// 2. page-layout.html uploaded to Supabase storage
// 3. All module JS files already loaded
// 
// After layout loads, you can listen for 'layoutReady' event:
// window.addEventListener('layoutReady', () => {
//     console.log('Layout is ready, initialize modules!');
// });
// ═══════════════════════════════════════════════════════════════
