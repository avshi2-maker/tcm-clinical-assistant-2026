// ═══════════════════════════════════════════════════════════════
// 🎓 TRAINING SYLLABUS MODULE - RIGHT PANEL (PURPLE BOX)
// ═══════════════════════════════════════════════════════════════
// Professional training syllabus for TCM practitioners
// 48 topics: 23 Pulse + 20 Tongue + 5 Elements
//
// Loaded from: Supabase Storage
// Called by: index.html
// Dependencies: supabaseClient (global)
// ═══════════════════════════════════════════════════════════════

(function() {
    'use strict';
    
    console.log('🎓 Loading Training Syllabus Module...');
    
    // ═══════════════════════════════════════════════════════════════
    // MODULE STATE
    // ═══════════════════════════════════════════════════════════════
    
    let trainingData = [];
    let currentTrainingFilter = 'all';
    
    // ═══════════════════════════════════════════════════════════════
    // TOGGLE & OPEN FUNCTIONS
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Toggle training syllabus content visibility
     */
    window.toggleTrainingSyllabus = function() {
        const content = document.getElementById('trainingContent');
        const icon = document.querySelector('.training-toggle-icon');
        
        if (!content || !icon) {
            console.error('❌ Training syllabus elements not found');
            return;
        }
        
        if (content.classList.contains('active')) {
            // Close
            content.classList.remove('active');
            icon.classList.remove('open');
        } else {
            // Open
            content.classList.add('active');
            icon.classList.add('open');
            
            // Load data on first open
            if (trainingData.length === 0) {
                console.log('📥 First time opening - loading training data...');
                loadTrainingData();
            }
        }
    };
    
    /**
     * Open training in full view mode
     */
    window.openTrainingFullView = function() {
        const content = document.getElementById('trainingContent');
        const icon = document.querySelector('.training-toggle-icon');
        
        if (!content || !icon) {
            console.error('❌ Training syllabus elements not found');
            return;
        }
        
        // Ensure it's open
        if (!content.classList.contains('active')) {
            content.classList.add('active');
            icon.classList.add('open');
            
            // Load data if needed
            if (trainingData.length === 0) {
                console.log('📥 Loading training data for full view...');
                loadTrainingData();
            }
        }
    };
    
    // ═══════════════════════════════════════════════════════════════
    // DATA LOADING
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Load training data from Supabase
     */
    async function loadTrainingData() {
        const loadingEl = document.getElementById('trainingLoading');
        const resultsEl = document.getElementById('trainingResults');
        
        if (!loadingEl || !resultsEl) {
            console.error('❌ Training loading/results elements not found');
            return;
        }
        
        try {
            const { data, error } = await supabaseClient
                .from('bible_rag_training_syllabus_20260129')
                .select('*')
                .order('category')
                .order('number');
            
            if (error) {
                console.error('❌ Error loading training data:', error);
                loadingEl.innerHTML = '<div style="color: red; font-size: 12px;">❌ שגיאה בטעינה</div>';
                return;
            }
            
            trainingData = data;
            console.log(`✅ Loaded ${data.length} training items`);
            
            // Hide loading, show results
            loadingEl.style.display = 'none';
            displayTrainingItems(trainingData);
            
        } catch (err) {
            console.error('❌ Exception loading training data:', err);
            loadingEl.innerHTML = '<div style="color: red; font-size: 12px;">❌ שגיאה</div>';
        }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // FILTERING & SEARCH
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Filter training items by category
     */
    window.filterTraining = function(category) {
        currentTrainingFilter = category;
        
        // Update active button
        document.querySelectorAll('.training-filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Mark clicked button as active
        if (event && event.target) {
            event.target.classList.add('active');
        }
        
        // Filter data
        let filtered = trainingData;
        
        if (category !== 'all') {
            const categoryMap = {
                'pulse': 'Pulse Diagnosis',
                'tongue': 'Tongue Diagnosis',
                'elements': 'Five Elements'
            };
            
            const targetCategory = categoryMap[category];
            filtered = trainingData.filter(item => item.category === targetCategory);
        }
        
        displayTrainingItems(filtered);
    };
    
    /**
     * Search training items by text
     */
    window.searchTraining = function() {
        const searchBox = document.getElementById('trainingSearchBox');
        if (!searchBox) {
            console.error('❌ Training search box not found');
            return;
        }
        
        const searchTerm = searchBox.value.toLowerCase();
        
        let filtered = trainingData;
        
        // Apply current category filter first
        if (currentTrainingFilter !== 'all') {
            const categoryMap = {
                'pulse': 'Pulse Diagnosis',
                'tongue': 'Tongue Diagnosis',
                'elements': 'Five Elements'
            };
            
            const targetCategory = categoryMap[currentTrainingFilter];
            filtered = filtered.filter(item => item.category === targetCategory);
        }
        
        // Apply search term
        if (searchTerm) {
            filtered = filtered.filter(item => 
                (item.name_hebrew && item.name_hebrew.toLowerCase().includes(searchTerm)) ||
                (item.name_english && item.name_english.toLowerCase().includes(searchTerm)) ||
                (item.clinical_description && item.clinical_description.toLowerCase().includes(searchTerm)) ||
                (item.acupuncture_points && item.acupuncture_points.toLowerCase().includes(searchTerm))
            );
        }
        
        displayTrainingItems(filtered);
    };
    
    // ═══════════════════════════════════════════════════════════════
    // DISPLAY
    // ═══════════════════════════════════════════════════════════════
    
    /**
     * Display training items in the results area
     */
    function displayTrainingItems(items) {
        const container = document.getElementById('trainingResults');
        
        if (!container) {
            console.error('❌ Training results container not found');
            return;
        }
        
        if (!items || items.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #666; font-size: 12px;">
                    <div style="font-size: 28px;">🔍</div>
                    <div style="margin-top: 10px;">לא נמצאו תוצאות</div>
                </div>
            `;
            return;
        }
        
        let html = '';
        
        items.forEach(item => {
            // Determine styling based on category
            const categoryClass = 
                item.category === 'Pulse Diagnosis' ? 'pulse-type' : 
                item.category === 'Tongue Diagnosis' ? 'tongue-type' : 
                'element-type';
            
            // Difficulty badge
            const badge = item.difficulty_level === 'Advanced' ? 
                '<span class="training-badge badge-advanced">מתקדם</span>' :
                '<span class="training-badge badge-intermediate">בינוני</span>';
            
            html += `
                <div class="training-item ${categoryClass}">
                    <div class="training-item-name">
                        ${item.name_hebrew || 'ללא שם'}
                        ${badge}
                    </div>
                    
                    ${item.clinical_description ? `
                    <div class="training-item-desc">
                        ${item.clinical_description}
                    </div>
                    ` : ''}
                    
                    ${item.acupuncture_points ? `
                    <div class="training-item-points">
                        <strong>נקודות:</strong> ${item.acupuncture_points}
                    </div>
                    ` : ''}
                    
                    ${item.treatment_principle ? `
                    <div class="training-item-treatment">
                        <strong>טיפול:</strong> ${item.treatment_principle}
                    </div>
                    ` : ''}
                </div>
            `;
        });
        
        container.innerHTML = html;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════════════
    
    console.log('✅ Training Syllabus Module loaded successfully');
    console.log('   📚 48 topics total');
    console.log('   💗 23 Pulse patterns');
    console.log('   👅 20 Tongue findings');
    console.log('   ⭐ 5 Five Elements');
    
})();
