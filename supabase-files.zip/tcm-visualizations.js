/**
 * ═══════════════════════════════════════════════════════════════════════════
 * 🎯 TCM VISUALIZATION SUITE - Complete Module
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Contains:
 * 1. 🌊 Meridian Map - 12 meridians with Qi flow animation
 * 2. 👂 Ear Map (Auricular) - Zones and treatment protocols
 * 3. 🦴 Anatomy Layers - Skin/Muscle/Bone toggle for needle depth
 * 
 * Upload to: Supabase Storage → modules → tcm-visualizations.js
 * 
 * Usage:
 *   TCMVisuals.showMeridian()  - Open meridian map
 *   TCMVisuals.showEar()       - Open ear map
 *   TCMVisuals.showAnatomy()   - Open anatomy layers
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

(function() {
    'use strict';
    
    console.log('\u{1F3AF} Loading TCM Visualization Suite...');
    
    // ═══════════════════════════════════════════════════════════════════════
    // SHARED STYLES
    // ═══════════════════════════════════════════════════════════════════════
    
    const sharedStyles = `
        .tcm-modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.92);
            z-index: 99999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 15px;
            overflow: auto;
        }
        .tcm-modal-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #1a1a2e 100%);
            border-radius: 16px;
            max-width: 1000px;
            width: 100%;
            max-height: 95vh;
            overflow: auto;
            position: relative;
            padding: 20px;
            box-shadow: 0 0 60px rgba(100,150,255,0.3);
            border: 1px solid rgba(100,150,255,0.2);
        }
        .tcm-close-btn {
            position: absolute;
            top: 10px;
            left: 10px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, #e53e3e, #c53030);
            color: white;
            font-size: 24px;
            cursor: pointer;
            z-index: 10;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.2s;
        }
        .tcm-close-btn:hover { transform: scale(1.1); }
        .tcm-title {
            text-align: center;
            color: white;
            margin: 0 0 8px 0;
            font-size: 22px;
            padding-top: 10px;
        }
        .tcm-subtitle {
            text-align: center;
            color: #8090b0;
            margin-bottom: 20px;
            font-size: 13px;
        }
        .tcm-container {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .tcm-visual-area {
            flex: 1;
            min-width: 280px;
            max-width: 400px;
        }
        .tcm-controls {
            flex: 0 0 280px;
            background: linear-gradient(135deg, rgba(30,60,100,0.8) 0%, rgba(50,30,80,0.8) 100%);
            padding: 16px;
            border-radius: 12px;
            border: 1px solid rgba(100,150,255,0.15);
        }
        .tcm-controls h3 {
            text-align: center;
            margin: 0 0 12px 0;
            font-size: 16px;
            color: white;
        }
        .tcm-section { margin-bottom: 14px; }
        .tcm-section-title {
            font-size: 12px;
            color: #a0b0c0;
            margin-bottom: 8px;
        }
        .tcm-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 5px;
        }
        .tcm-grid-2 {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 6px;
        }
        .tcm-btn {
            padding: 8px 6px;
            border-radius: 8px;
            border: 2px solid;
            background: rgba(0,0,0,0.3);
            color: white;
            cursor: pointer;
            font-size: 11px;
            font-weight: bold;
            text-align: center;
            transition: all 0.2s;
        }
        .tcm-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 12px currentColor;
        }
        .tcm-btn.active {
            box-shadow: 0 0 15px currentColor, inset 0 0 8px rgba(255,255,255,0.2);
        }
        .tcm-tag-btn {
            padding: 6px 10px;
            border-radius: 20px;
            border: 1px solid #666;
            background: rgba(255,255,255,0.1);
            color: white;
            cursor: pointer;
            font-size: 11px;
            transition: all 0.2s;
            margin: 2px;
        }
        .tcm-tag-btn:hover {
            background: #8B5CF6;
            border-color: #8B5CF6;
        }
        .tcm-info-panel {
            background: rgba(0,0,0,0.4);
            padding: 12px;
            border-radius: 10px;
            display: none;
            border: 1px solid rgba(100,150,255,0.15);
            margin-top: 10px;
        }
        .tcm-info-panel.show { display: block; }
        .tcm-info-panel h4 {
            margin: 0 0 8px 0;
            font-size: 15px;
            color: white;
        }
        .tcm-info-panel p {
            font-size: 12px;
            color: #c0d0e0;
            margin: 4px 0;
            line-height: 1.4;
        }
        .tcm-action-btns {
            display: flex;
            gap: 8px;
            margin: 12px 0;
        }
        .tcm-action-btns button {
            flex: 1;
            padding: 10px;
            border-radius: 8px;
            border: none;
            color: white;
            cursor: pointer;
            font-weight: bold;
            font-size: 12px;
        }
        .tcm-action-btns button:disabled { opacity: 0.5; cursor: not-allowed; }
        .tcm-slider-control { margin-bottom: 10px; }
        .tcm-slider-control label { font-size: 12px; color: #ccc; }
        .tcm-slider-control input { width: 100%; margin-top: 4px; }
        @media (max-width: 600px) {
            .tcm-modal-content { padding: 15px; }
            .tcm-title { font-size: 18px; }
            .tcm-controls { flex: 1 1 100%; }
        }
    `;
    
    // ═══════════════════════════════════════════════════════════════════════
    // HEBREW TEXT (Unicode escaped)
    // ═══════════════════════════════════════════════════════════════════════
    
    const HE = {
        // Meridian
        merTitle: '\u{1F30A} \u05DE\u05E4\u05EA \u05DE\u05E8\u05D9\u05D3\u05D9\u05D0\u05E0\u05D9\u05DD',
        merSubtitle: '\u05DC\u05D7\u05E5 \u05E2\u05DC \u05DE\u05E8\u05D9\u05D3\u05D9\u05D0\u05DF \u05DC\u05D4\u05E6\u05D2\u05EA \u05D6\u05E8\u05D9\u05DE\u05EA \u05E6\'\u05D9',
        merControls: '\u{1F30A} \u05D1\u05D7\u05D9\u05E8\u05EA \u05DE\u05E8\u05D9\u05D3\u05D9\u05D0\u05DF',
        all: '\u05D4\u05DB\u05DC',
        yin: '\u262F \u05D9\u05D9\u05DF',
        yang: '\u262F \u05D9\u05D0\u05E0\u05D2',
        yinLabel: '\u05D9\u05D9\u05DF (Yin):',
        yangLabel: '\u05D9\u05D0\u05E0\u05D2 (Yang):',
        start: '\u25B6 \u05D4\u05E4\u05E2\u05DC',
        stop: '\u23F9 \u05E2\u05E6\u05D5\u05E8',
        speed: '\u05DE\u05D4\u05D9\u05E8\u05D5\u05EA:',
        points: '\u05E0\u05E7\u05D5\u05D3\u05D5\u05EA:',
        element: '\u05D9\u05E1\u05D5\u05D3:',
        selectFirst: '\u05D1\u05D7\u05E8 \u05DE\u05E8\u05D9\u05D3\u05D9\u05D0\u05DF!',
        
        // Ear
        earTitle: '\u{1F442} \u05DE\u05E4\u05EA \u05D0\u05D5\u05D6\u05DF',
        earSubtitle: 'Auricular - \u05DE\u05D9\u05E7\u05E8\u05D5-\u05DE\u05E2\u05E8\u05DB\u05EA \u05DC\u05D8\u05D9\u05E4\u05D5\u05DC',
        earControls: '\u{1F442} \u05D0\u05D6\u05D5\u05E8\u05D9\u05DD \u05D5\u05E4\u05E8\u05D5\u05D8\u05D5\u05E7\u05D5\u05DC\u05D9\u05DD',
        zones: '\u05D0\u05D6\u05D5\u05E8\u05D9\u05DD:',
        protocols: '\u05E4\u05E8\u05D5\u05D8\u05D5\u05E7\u05D5\u05DC\u05D9\u05DD:',
        
        // Anatomy
        anaTitle: '\u{1F9B4} \u05E9\u05DB\u05D1\u05D5\u05EA \u05D0\u05E0\u05D8\u05D5\u05DE\u05D9\u05D4',
        anaSubtitle: '\u05D4\u05E4\u05E2\u05DC/\u05DB\u05D1\u05D4 \u05E9\u05DB\u05D1\u05D5\u05EA \u05DC\u05E8\u05D0\u05D5\u05EA \u05E2\u05D5\u05DE\u05E7 \u05D3\u05E7\u05D9\u05E8\u05D4',
        anaControls: '\u{1F39B} \u05E9\u05DC\u05D9\u05D8\u05D4 \u05D1\u05E9\u05DB\u05D1\u05D5\u05EA',
        layers: '\u05E9\u05DB\u05D1\u05D5\u05EA:',
        skin: '\u{1F9F4} \u05E2\u05D5\u05E8',
        muscle: '\u{1F4AA} \u05E9\u05E8\u05D9\u05E8\u05D9\u05DD',
        bone: '\u{1F9B4} \u05E2\u05E6\u05DE\u05D5\u05EA',
        presets: '\u05EA\u05E6\u05D5\u05D2\u05D5\u05EA:',
        xray: '\u05E8\u05E0\u05D8\u05D2\u05DF',
        depthLabel: '\u05E2\u05D5\u05DE\u05E7:',
        tip: '\u05D8\u05D9\u05E4:'
    };
    
    // ═══════════════════════════════════════════════════════════════════════
    // MERIDIAN DATA
    // ═══════════════════════════════════════════════════════════════════════
    
    const meridians = {
        LU: { nameHe: '\u05E8\u05D9\u05D0\u05D5\u05EA', nameCn: '\u80BA\u7ECF', type: 'yin', element: '\u05DE\u05EA\u05DB\u05EA', color: '#87CEEB', flow: 'down', points: ['LU1','LU5','LU7','LU9','LU11'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05E0\u05E9\u05D9\u05DE\u05D4 \u05D5\u05DE\u05E2\u05E8\u05DB\u05EA \u05D4\u05D7\u05D9\u05E1\u05D5\u05DF' },
        LI: { nameHe: '\u05DE\u05E2\u05D9 \u05D2\u05E1', nameCn: '\u5927\u80A0\u7ECF', type: 'yang', element: '\u05DE\u05EA\u05DB\u05EA', color: '#E0E0E0', flow: 'up', points: ['LI1','LI4','LI11','LI20'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05D4\u05E4\u05E8\u05E9\u05D4 \u05D5\u05E0\u05D9\u05E7\u05D5\u05D9 \u05E8\u05E2\u05DC\u05D9\u05DD' },
        ST: { nameHe: '\u05E7\u05D9\u05D1\u05D4', nameCn: '\u80C3\u7ECF', type: 'yang', element: '\u05D0\u05D3\u05DE\u05D4', color: '#FFA500', flow: 'down', points: ['ST25','ST36','ST44'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05E2\u05D9\u05DB\u05D5\u05DC. ST36 \u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05D1\u05E8\u05D9\u05D0\u05D5\u05EA!' },
        SP: { nameHe: '\u05D8\u05D7\u05D5\u05DC', nameCn: '\u813E\u7ECF', type: 'yin', element: '\u05D0\u05D3\u05DE\u05D4', color: '#FFD700', flow: 'up', points: ['SP3','SP6','SP9'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05E2\u05D9\u05DB\u05D5\u05DC \u05D5\u05D4\u05E4\u05E7\u05EA \u05D0\u05E0\u05E8\u05D2\u05D9\u05D4' },
        HT: { nameHe: '\u05DC\u05D1', nameCn: '\u5FC3\u7ECF', type: 'yin', element: '\u05D0\u05E9', color: '#FF4444', flow: 'down', points: ['HT3','HT7','HT9'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05D3\u05DD \u05D5\u05EA\u05D5\u05D3\u05E2\u05D4' },
        SI: { nameHe: '\u05DE\u05E2\u05D9 \u05D3\u05E7', nameCn: '\u5C0F\u80A0\u7ECF', type: 'yang', element: '\u05D0\u05E9', color: '#FF6347', flow: 'up', points: ['SI3','SI5','SI19'], desc: '\u05DE\u05E4\u05E8\u05D9\u05D3 \u05D8\u05D4\u05D5\u05E8 \u05DE\u05E2\u05DB\u05D5\u05E8' },
        BL: { nameHe: '\u05E9\u05DC\u05E4\u05D5\u05D7\u05D9\u05EA', nameCn: '\u8180\u80F1\u7ECF', type: 'yang', element: '\u05DE\u05D9\u05DD', color: '#0000CD', flow: 'down', points: ['BL10','BL23','BL40','BL67'], desc: '\u05D4\u05DE\u05E8\u05D9\u05D3\u05D9\u05D0\u05DF \u05D4\u05D0\u05E8\u05D5\u05DA \u05D1\u05D9\u05D5\u05EA\u05E8!' },
        KI: { nameHe: '\u05DB\u05DC\u05D9\u05D5\u05EA', nameCn: '\u80BE\u7ECF', type: 'yin', element: '\u05DE\u05D9\u05DD', color: '#4169E1', flow: 'up', points: ['KI1','KI3','KI6','KI27'], desc: '\u05E9\u05D5\u05E8\u05E9 \u05D4\u05D7\u05D9\u05D9\u05DD!' },
        PC: { nameHe: '\u05E4\u05E8\u05D9\u05E7\u05E8\u05D3', nameCn: '\u5FC3\u5305\u7ECF', type: 'yin', element: '\u05D0\u05E9', color: '#DC143C', flow: 'down', points: ['PC3','PC6','PC7'], desc: '\u05DE\u05D2\u05DF \u05E2\u05DC \u05D4\u05DC\u05D1. PC6 \u05E0\u05D2\u05D3 \u05D1\u05D7\u05D9\u05DC\u05D5\u05EA!' },
        SJ: { nameHe: '\u05E1\u05D0\u05DF \u05D2\'\u05D9\u05D0\u05D5', nameCn: '\u4E09\u7126\u7ECF', type: 'yang', element: '\u05D0\u05E9', color: '#FF8C00', flow: 'up', points: ['SJ5','SJ6','SJ17'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05EA\u05E0\u05D5\u05E2\u05EA \u05E0\u05D5\u05D6\u05DC\u05D9\u05DD' },
        GB: { nameHe: '\u05DB\u05D9\u05E1 \u05DE\u05E8\u05D4', nameCn: '\u80C6\u7ECF', type: 'yang', element: '\u05E2\u05E5', color: '#00FF00', flow: 'down', points: ['GB20','GB21','GB34','GB44'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05D4\u05D7\u05DC\u05D8\u05D5\u05EA' },
        LV: { nameHe: '\u05DB\u05D1\u05D3', nameCn: '\u809D\u7ECF', type: 'yin', element: '\u05E2\u05E5', color: '#32CD32', flow: 'up', points: ['LV2','LV3','LV8','LV14'], desc: '\u05E9\u05D5\u05DC\u05D8 \u05D1\u05D6\u05E8\u05D9\u05DE\u05EA \u05E6\'\u05D9' }
    };
    
    // ═══════════════════════════════════════════════════════════════════════
    // EAR DATA
    // ═══════════════════════════════════════════════════════════════════════
    
    const earZones = {
        helix: { name: 'Helix', nameHe: '\u05D2\u05D5\u05E3/\u05E8\u05D0\u05E9', color: '#FF6B6B', desc: '\u05DE\u05D9\u05D9\u05E6\u05D2 \u05D0\u05EA \u05D4\u05D2\u05D5\u05E3 \u05DE\u05D1\u05D7\u05D5\u05E5' },
        antihelix: { name: 'Antihelix', nameHe: '\u05E2\u05DE\u05D5\u05D3 \u05E9\u05D3\u05E8\u05D4', color: '#4ECDC4', desc: '\u05DE\u05E2\u05D5\u05DC\u05D4 \u05DC\u05DB\u05D0\u05D1\u05D9 \u05D2\u05D1' },
        concha: { name: 'Concha', nameHe: '\u05D0\u05D9\u05D1\u05E8\u05D9\u05DD \u05E4\u05E0\u05D9\u05DE\u05D9\u05D9\u05DD', color: '#9B59B6', desc: '\u05DC\u05D1, \u05E8\u05D9\u05D0\u05D5\u05EA, \u05DB\u05D1\u05D3, \u05DB\u05DC\u05D9\u05D5\u05EA, \u05E7\u05D9\u05D1\u05D4' },
        tragus: { name: 'Tragus', nameHe: '\u05D0\u05D3\u05E8\u05E0\u05DC/\u05EA\u05D9\u05D0\u05D1\u05D5\u05DF', color: '#F39C12', desc: '\u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05E8\u05E2\u05D1 - \u05DE\u05E2\u05D5\u05DC\u05D4 \u05DC\u05D3\u05D9\u05D0\u05D8\u05D4!' },
        antitragus: { name: 'Antitragus', nameHe: '\u05E8\u05D0\u05E9/\u05DE\u05D5\u05D7', color: '#E74C3C', desc: '\u05DB\u05D0\u05D1\u05D9 \u05E8\u05D0\u05E9, \u05E1\u05D7\u05E8\u05D7\u05D5\u05E8\u05EA' },
        lobe: { name: 'Lobe', nameHe: '\u05E4\u05E0\u05D9\u05DD/\u05E2\u05D9\u05E0\u05D9\u05D9\u05DD', color: '#3498DB', desc: '\u05E2\u05D9\u05E0\u05D9\u05D9\u05DD, \u05DC\u05E1\u05EA, \u05E9\u05D9\u05E0\u05D9\u05D9\u05DD' }
    };
    
    const earProtocols = {
        pain: { name: '\u05DB\u05D0\u05D1', points: ['Shenmen', 'Point Zero', 'Sympathetic'] },
        anxiety: { name: '\u05D7\u05E8\u05D3\u05D4', points: ['Shenmen', 'Heart', 'Sympathetic'] },
        insomnia: { name: '\u05E9\u05D9\u05E0\u05D4', points: ['Shenmen', 'Heart', 'Kidney'] },
        addiction: { name: '\u05D4\u05EA\u05DE\u05DB\u05E8\u05D5\u05EA (NADA)', points: ['Shenmen', 'Sympathetic', 'Kidney', 'Liver', 'Lung'] },
        weight: { name: '\u05DE\u05E9\u05E7\u05DC', points: ['Hunger', 'Stomach', 'Endocrine'] },
        headache: { name: '\u05DB\u05D0\u05D1 \u05E8\u05D0\u05E9', points: ['Shenmen', 'Point Zero', 'Sympathetic'] },
        digestion: { name: '\u05E2\u05D9\u05DB\u05D5\u05DC', points: ['Stomach', 'Liver', 'Shenmen'] },
        stress: { name: '\u05DC\u05D7\u05E5', points: ['Shenmen', 'Sympathetic', 'Endocrine', 'Heart'] }
    };
    
    // ═══════════════════════════════════════════════════════════════════════
    // ANATOMY DATA
    // ═══════════════════════════════════════════════════════════════════════
    
    const acupoints = {
        'ST36': { name: 'ST36 - \u8DB3\u4E09\u91CC', depth: '1.5-2 \u05E6\u05D5\u05DF (3-4 \u05E1"\u05DE)', tip: '\u05D3\u05E7\u05D5\u05E8 \u05D0\u05E0\u05DB\u05D9. \u05E0\u05E7\u05D5\u05D3\u05D4 \u05E2\u05DE\u05D5\u05E7\u05D4.' },
        'LI4': { name: 'LI4 - \u5408\u8C37', depth: '0.5-1 \u05E6\u05D5\u05DF', tip: '\u05DC\u05D0 \u05DC\u05E0\u05E9\u05D9\u05DD \u05D1\u05D4\u05E8\u05D9\u05D5\u05DF!' },
        'LV3': { name: 'LV3 - \u592A\u51B2', depth: '0.5-0.8 \u05E6\u05D5\u05DF', tip: '\u05E0\u05E7\u05D5\u05D3\u05D4 \u05E8\u05D2\u05D9\u05E9\u05D4!' },
        'PC6': { name: 'PC6 - \u5185\u5173', depth: '0.5-1 \u05E6\u05D5\u05DF', tip: '\u05E9\u05D9\u05DD \u05DC\u05D1 \u05DC\u05E2\u05E6\u05D1!' },
        'SP6': { name: 'SP6 - \u4E09\u9634\u4EA4', depth: '1-1.5 \u05E6\u05D5\u05DF', tip: '\u05DC\u05D0 \u05DC\u05E0\u05E9\u05D9\u05DD \u05D1\u05D4\u05E8\u05D9\u05D5\u05DF!' },
        'CV6': { name: 'CV6 - \u6C14\u6D77', depth: '1-1.5 \u05E6\u05D5\u05DF', tip: '\u05E7\u05E8\u05D5\u05D1 \u05DC\u05D0\u05D9\u05D1\u05E8\u05D9\u05DD \u05E4\u05E0\u05D9\u05DE\u05D9\u05D9\u05DD!' }
    };
    
    // ═══════════════════════════════════════════════════════════════════════
    // UTILITY FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════
    
    function injectStyles() {
        if (document.getElementById('tcm-visual-styles')) return;
        const style = document.createElement('style');
        style.id = 'tcm-visual-styles';
        style.textContent = sharedStyles;
        document.head.appendChild(style);
    }
    
    function createModal(id, content) {
        let modal = document.getElementById(id);
        if (modal) { modal.remove(); }
        
        modal = document.createElement('div');
        modal.id = id;
        modal.className = 'tcm-modal-overlay';
        modal.innerHTML = `
            <div class="tcm-modal-content" dir="rtl">
                <button class="tcm-close-btn" onclick="TCMVisuals.close('${id}')">\u2715</button>
                ${content}
            </div>
        `;
        document.body.appendChild(modal);
        document.body.style.overflow = 'hidden';
        return modal;
    }
    
    function closeModal(id) {
        const modal = document.getElementById(id);
        if (modal) { modal.remove(); }
        document.body.style.overflow = 'auto';
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MERIDIAN MODULE
    // ═══════════════════════════════════════════════════════════════════════
    
    let merCurrent = null;
    let merSpeed = 1;
    
    function getMeridianHTML() {
        const yinBtns = Object.entries(meridians).filter(([,m]) => m.type === 'yin').map(([code, m]) => 
            `<button class="tcm-btn mer-btn" style="border-color:${m.color};color:${m.color}" data-code="${code}" onclick="TCMVisuals._merSelect('${code}')">${code}<br><small>${m.nameHe}</small></button>`
        ).join('');
        
        const yangBtns = Object.entries(meridians).filter(([,m]) => m.type === 'yang').map(([code, m]) => 
            `<button class="tcm-btn mer-btn" style="border-color:${m.color};color:${m.color}" data-code="${code}" onclick="TCMVisuals._merSelect('${code}')">${code}<br><small>${m.nameHe}</small></button>`
        ).join('');
        
        return `
            <h2 class="tcm-title">${HE.merTitle}</h2>
            <p class="tcm-subtitle">${HE.merSubtitle}</p>
            <div class="tcm-container">
                <div class="tcm-visual-area">
                    <svg viewBox="0 0 400 700" style="width:100%;background:linear-gradient(180deg,#1a1a2e,#16213e);border-radius:12px;">
                        <defs>
                            <filter id="merGlow"><feGaussianBlur stdDeviation="3"/><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge></filter>
                        </defs>
                        <g id="merBody">
                            <ellipse cx="200" cy="55" rx="38" ry="48" fill="#2d3748" stroke="#4a5568" stroke-width="2"/>
                            <rect x="185" y="98" width="30" height="22" fill="#2d3748"/>
                            <path d="M 150,120 Q 135,180 140,280 Q 145,380 160,420 L 240,420 Q 255,380 260,280 Q 265,180 250,120 Z" fill="#2d3748" stroke="#4a5568" stroke-width="2"/>
                            <path d="M 150,125 Q 120,150 95,220 Q 75,290 60,360 Q 50,410 45,450" fill="none" stroke="#2d3748" stroke-width="28" stroke-linecap="round"/>
                            <path d="M 250,125 Q 280,150 305,220 Q 325,290 340,360 Q 350,410 355,450" fill="none" stroke="#2d3748" stroke-width="28" stroke-linecap="round"/>
                            <path d="M 160,420 Q 155,490 150,560 Q 148,600 145,640" fill="none" stroke="#2d3748" stroke-width="32" stroke-linecap="round"/>
                            <path d="M 240,420 Q 245,490 250,560 Q 252,600 255,640" fill="none" stroke="#2d3748" stroke-width="32" stroke-linecap="round"/>
                        </g>
                        <g id="merPaths">
                            <path id="mp-LU" d="M 140,130 Q 120,160 110,200 Q 100,250 90,300 Q 80,350 70,400" fill="none" stroke="#87CEEB" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-LI" d="M 70,400 Q 85,340 100,280 Q 115,220 130,160 Q 145,120 165,80" fill="none" stroke="#E0E0E0" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-ST" d="M 180,70 Q 185,120 190,180 Q 195,260 200,340 Q 205,420 210,500 Q 215,560 220,600" fill="none" stroke="#FFA500" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-SP" d="M 175,580 Q 170,500 165,420 Q 160,340 155,260 Q 150,180 145,130" fill="none" stroke="#FFD700" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-HT" d="M 150,135 Q 135,170 125,220 Q 115,280 105,340 Q 95,380 85,410" fill="none" stroke="#FF4444" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-SI" d="M 85,410 Q 100,350 115,290 Q 130,230 150,170 Q 170,120 190,70" fill="none" stroke="#FF6347" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-BL" d="M 210,50 Q 220,100 225,180 Q 230,280 235,380 Q 240,480 245,580" fill="none" stroke="#0000CD" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-KI" d="M 190,590 Q 185,500 180,420 Q 175,340 170,260 Q 165,180 160,130" fill="none" stroke="#4169E1" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-PC" d="M 145,135 Q 130,180 120,240 Q 110,300 100,360 Q 90,400 80,430" fill="none" stroke="#DC143C" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-SJ" d="M 80,430 Q 95,370 115,310 Q 135,250 155,190 Q 175,130 200,70" fill="none" stroke="#FF8C00" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-GB" d="M 230,60 Q 240,120 245,200 Q 250,300 255,400 Q 260,500 265,590" fill="none" stroke="#00FF00" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                            <path id="mp-LV" d="M 200,585 Q 195,500 190,420 Q 185,340 180,260 Q 175,180 170,130" fill="none" stroke="#32CD32" stroke-width="3" stroke-opacity="0.4" stroke-linecap="round"/>
                        </g>
                    </svg>
                </div>
                <div class="tcm-controls">
                    <h3>${HE.merControls}</h3>
                    <div class="tcm-section">
                        <div style="display:flex;gap:6px;margin-bottom:10px;">
                            <button class="tcm-btn" style="flex:1;border-color:#666;color:#ccc" onclick="TCMVisuals._merFilter('all')">${HE.all}</button>
                            <button class="tcm-btn" style="flex:1;border-color:#9B59B6;color:#9B59B6" onclick="TCMVisuals._merFilter('yin')">${HE.yin}</button>
                            <button class="tcm-btn" style="flex:1;border-color:#E74C3C;color:#E74C3C" onclick="TCMVisuals._merFilter('yang')">${HE.yang}</button>
                        </div>
                    </div>
                    <div class="tcm-section">
                        <div class="tcm-section-title">${HE.yinLabel}</div>
                        <div class="tcm-grid">${yinBtns}</div>
                    </div>
                    <div class="tcm-section">
                        <div class="tcm-section-title">${HE.yangLabel}</div>
                        <div class="tcm-grid">${yangBtns}</div>
                    </div>
                    <div class="tcm-action-btns">
                        <button id="merStart" style="background:#38a169" onclick="TCMVisuals._merStart()">${HE.start}</button>
                        <button id="merStop" style="background:#e53e3e" onclick="TCMVisuals._merStop()" disabled>${HE.stop}</button>
                    </div>
                    <div class="tcm-slider-control">
                        <label>${HE.speed} <span id="merSpeedVal">1x</span></label>
                        <input type="range" min="0.5" max="3" step="0.5" value="1" onchange="TCMVisuals._merSpeed(this.value)">
                    </div>
                    <div id="merInfo" class="tcm-info-panel">
                        <h4 id="merInfoTitle"></h4>
                        <p id="merInfoEl"></p>
                        <p id="merInfoDesc"></p>
                        <p><strong>${HE.points}</strong> <span id="merInfoPts"></span></p>
                    </div>
                </div>
            </div>
        `;
    }
    
    function merSelect(code) {
        merStop();
        merCurrent = code;
        const m = meridians[code];
        
        document.querySelectorAll('#merPaths path').forEach(p => {
            p.style.strokeOpacity = '0.4';
            p.style.strokeWidth = '3';
            p.style.filter = '';
            p.classList.remove('mer-flowing');
        });
        document.querySelectorAll('.mer-btn').forEach(b => b.classList.remove('active'));
        
        const path = document.getElementById('mp-' + code);
        const btn = document.querySelector('.mer-btn[data-code="' + code + '"]');
        if (path) { path.style.strokeOpacity = '1'; path.style.strokeWidth = '5'; path.style.filter = 'url(#merGlow)'; }
        if (btn) btn.classList.add('active');
        
        document.getElementById('merInfo').classList.add('show');
        document.getElementById('merInfoTitle').innerHTML = '<span style="color:' + m.color + '">' + m.nameCn + '</span> ' + m.nameHe + ' (' + code + ')';
        document.getElementById('merInfoEl').innerHTML = HE.element + ' <strong style="color:' + m.color + '">' + m.element + '</strong> | ' + (m.type === 'yin' ? HE.yin : HE.yang);
        document.getElementById('merInfoDesc').textContent = m.desc;
        document.getElementById('merInfoPts').textContent = m.points.join(', ');
    }
    
    function merFilter(type) {
        document.querySelectorAll('#merPaths path').forEach(p => {
            const code = p.id.replace('mp-', '');
            const m = meridians[code];
            p.style.strokeOpacity = (type === 'all' || m.type === type) ? '0.5' : '0.1';
        });
    }
    
    function merStart() {
        if (!merCurrent) { alert(HE.selectFirst); return; }
        const m = meridians[merCurrent];
        const path = document.getElementById('mp-' + merCurrent);
        if (path) {
            const dir = m.flow === 'up' ? 30 : -30;
            path.style.strokeDasharray = '15 15';
            path.style.animation = `merFlow ${0.8 / merSpeed}s linear infinite`;
            path.dataset.dir = dir;
            
            if (!document.getElementById('merFlowStyle')) {
                const s = document.createElement('style');
                s.id = 'merFlowStyle';
                s.textContent = `@keyframes merFlow { from { stroke-dashoffset: 0; } to { stroke-dashoffset: var(--flow-dir, -30); } }`;
                document.head.appendChild(s);
            }
            path.style.setProperty('--flow-dir', dir + 'px');
        }
        document.getElementById('merStart').disabled = true;
        document.getElementById('merStop').disabled = false;
    }
    
    function merStop() {
        document.querySelectorAll('#merPaths path').forEach(p => {
            p.style.strokeDasharray = '';
            p.style.animation = '';
        });
        const startBtn = document.getElementById('merStart');
        const stopBtn = document.getElementById('merStop');
        if (startBtn) startBtn.disabled = false;
        if (stopBtn) stopBtn.disabled = true;
    }
    
    function merSetSpeed(val) {
        merSpeed = parseFloat(val);
        document.getElementById('merSpeedVal').textContent = val + 'x';
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // EAR MODULE
    // ═══════════════════════════════════════════════════════════════════════
    
    function getEarHTML() {
        const zoneBtns = Object.entries(earZones).map(([id, z]) => 
            `<button class="tcm-btn ear-zone-btn" style="border-color:${z.color};color:${z.color}" data-zone="${id}" onclick="TCMVisuals._earZone('${id}')">${z.name}<br><small>${z.nameHe}</small></button>`
        ).join('');
        
        const protocolBtns = Object.entries(earProtocols).map(([id, p]) => 
            `<button class="tcm-tag-btn" onclick="TCMVisuals._earProtocol('${id}')">${p.name}</button>`
        ).join('');
        
        return `
            <h2 class="tcm-title">${HE.earTitle}</h2>
            <p class="tcm-subtitle">${HE.earSubtitle}</p>
            <div class="tcm-container">
                <div class="tcm-visual-area">
                    <svg viewBox="0 0 300 400" style="width:100%;filter:drop-shadow(0 0 20px rgba(100,150,255,0.3));">
                        <defs><linearGradient id="earGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#FFE4C4"/><stop offset="100%" stop-color="#DEB887"/></linearGradient></defs>
                        <path d="M 150,30 Q 220,40 240,100 Q 260,160 250,220 Q 240,280 220,320 Q 200,360 160,380 Q 120,390 100,370 Q 80,350 90,310 Q 100,270 90,230 Q 80,190 90,150 Q 100,110 120,80 Q 140,50 150,30" fill="url(#earGrad)" stroke="#8B7355" stroke-width="3"/>
                        <path id="ez-helix" class="ear-svg-zone" data-zone="helix" d="M 150,35 Q 215,45 235,100 Q 250,150 245,200 Q 240,250 225,290" fill="none" stroke="#FF6B6B" stroke-width="12" stroke-linecap="round" opacity="0.6" style="cursor:pointer"/>
                        <path id="ez-antihelix" class="ear-svg-zone" data-zone="antihelix" d="M 160,80 Q 180,120 175,180 Q 170,240 165,280" fill="none" stroke="#4ECDC4" stroke-width="15" stroke-linecap="round" opacity="0.6" style="cursor:pointer"/>
                        <ellipse id="ez-concha" class="ear-svg-zone" data-zone="concha" cx="140" cy="220" rx="35" ry="45" fill="#9B59B6" opacity="0.5" style="cursor:pointer"/>
                        <ellipse id="ez-tragus" class="ear-svg-zone" data-zone="tragus" cx="95" cy="200" rx="18" ry="25" fill="#F39C12" opacity="0.5" style="cursor:pointer"/>
                        <ellipse id="ez-antitragus" class="ear-svg-zone" data-zone="antitragus" cx="120" cy="300" rx="20" ry="18" fill="#E74C3C" opacity="0.5" style="cursor:pointer"/>
                        <ellipse id="ez-lobe" class="ear-svg-zone" data-zone="lobe" cx="130" cy="355" rx="30" ry="25" fill="#3498DB" opacity="0.5" style="cursor:pointer"/>
                        <g id="earPoints">
                            <circle id="ep-shenmen" cx="175" cy="130" r="5" fill="#FFD700" style="cursor:pointer"/><text x="185" y="135" fill="#FFD700" font-size="9">Shenmen</text>
                            <circle id="ep-zero" cx="155" cy="190" r="5" fill="#00FF00" style="cursor:pointer"/><text x="165" y="195" fill="#00FF00" font-size="9">Point Zero</text>
                            <circle id="ep-sympathetic" cx="165" cy="105" r="5" fill="#FF69B4" style="cursor:pointer"/>
                            <circle id="ep-heart" cx="130" cy="210" r="5" fill="#FF0000" style="cursor:pointer"/>
                            <circle id="ep-lung" cx="150" cy="230" r="5" fill="#87CEEB" style="cursor:pointer"/>
                            <circle id="ep-liver" cx="125" cy="240" r="5" fill="#228B22" style="cursor:pointer"/>
                            <circle id="ep-kidney" cx="155" cy="250" r="5" fill="#000080" style="cursor:pointer"/>
                            <circle id="ep-stomach" cx="140" cy="260" r="5" fill="#FFA500" style="cursor:pointer"/>
                            <circle id="ep-hunger" cx="90" cy="185" r="5" fill="#FFA500" style="cursor:pointer"/>
                            <circle id="ep-endocrine" cx="95" cy="230" r="5" fill="#00CED1" style="cursor:pointer"/>
                        </g>
                    </svg>
                </div>
                <div class="tcm-controls">
                    <h3>${HE.earControls}</h3>
                    <div class="tcm-section">
                        <div class="tcm-section-title">${HE.zones}</div>
                        <div class="tcm-grid-2">${zoneBtns}</div>
                    </div>
                    <div class="tcm-section">
                        <div class="tcm-section-title">${HE.protocols}</div>
                        <div style="display:flex;flex-wrap:wrap;">${protocolBtns}</div>
                    </div>
                    <div id="earInfo" class="tcm-info-panel">
                        <h4 id="earInfoTitle"></h4>
                        <p id="earInfoDesc"></p>
                        <p id="earInfoPts"></p>
                    </div>
                </div>
            </div>
        `;
    }
    
    function earSelectZone(id) {
        document.querySelectorAll('.ear-svg-zone').forEach(z => { z.style.filter = ''; z.style.opacity = z.tagName === 'ellipse' ? '0.5' : '0.6'; });
        document.querySelectorAll('#earPoints circle').forEach(p => { p.setAttribute('r', '5'); p.style.filter = ''; });
        
        const zone = document.getElementById('ez-' + id);
        if (zone) { zone.style.filter = 'drop-shadow(0 0 10px ' + earZones[id].color + ')'; zone.style.opacity = '0.9'; }
        
        const z = earZones[id];
        document.getElementById('earInfo').classList.add('show');
        document.getElementById('earInfoTitle').innerHTML = '<span style="color:' + z.color + '">' + z.name + '</span> - ' + z.nameHe;
        document.getElementById('earInfoDesc').textContent = z.desc;
        document.getElementById('earInfoPts').textContent = '';
    }
    
    function earShowProtocol(id) {
        document.querySelectorAll('.ear-svg-zone').forEach(z => { z.style.filter = ''; z.style.opacity = z.tagName === 'ellipse' ? '0.5' : '0.6'; });
        document.querySelectorAll('#earPoints circle').forEach(p => { p.setAttribute('r', '5'); p.style.filter = ''; });
        
        const p = earProtocols[id];
        p.points.forEach(pt => {
            const el = document.getElementById('ep-' + pt.toLowerCase().replace(' ', ''));
            if (el) { el.setAttribute('r', '8'); el.style.filter = 'drop-shadow(0 0 8px #FFD700)'; }
        });
        
        document.getElementById('earInfo').classList.add('show');
        document.getElementById('earInfoTitle').textContent = '\u{1FA7A} ' + p.name;
        document.getElementById('earInfoDesc').textContent = '';
        document.getElementById('earInfoPts').innerHTML = '<strong>' + HE.points + '</strong> ' + p.points.join(' \u2022 ');
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // ANATOMY MODULE
    // ═══════════════════════════════════════════════════════════════════════
    
    function getAnatomyHTML() {
        return `
            <h2 class="tcm-title">${HE.anaTitle}</h2>
            <p class="tcm-subtitle">${HE.anaSubtitle}</p>
            <div class="tcm-container">
                <div class="tcm-visual-area">
                    <svg viewBox="0 0 300 500" style="width:100%;background:linear-gradient(180deg,#1a1a2e,#0d0d1a);border-radius:12px;">
                        <defs>
                            <linearGradient id="skinG" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#FFE4C4"/><stop offset="100%" stop-color="#DEB887"/></linearGradient>
                            <linearGradient id="muscleG" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#CD5C5C"/><stop offset="100%" stop-color="#8B0000"/></linearGradient>
                            <linearGradient id="boneG" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#FFFAF0"/><stop offset="100%" stop-color="#F5DEB3"/></linearGradient>
                        </defs>
                        <g id="anaLayerBone">
                            <ellipse cx="150" cy="50" rx="30" ry="35" fill="url(#boneG)" stroke="#8B8378"/>
                            <rect x="145" y="80" width="10" height="150" rx="3" fill="url(#boneG)" stroke="#8B8378"/>
                            <ellipse cx="150" cy="230" rx="45" ry="25" fill="url(#boneG)" stroke="#8B8378"/>
                            <line x1="95" y1="100" x2="60" y2="200" stroke="#F5DEB3" stroke-width="6" stroke-linecap="round"/>
                            <line x1="205" y1="100" x2="240" y2="200" stroke="#F5DEB3" stroke-width="6" stroke-linecap="round"/>
                            <line x1="125" y1="250" x2="115" y2="400" stroke="#F5DEB3" stroke-width="8" stroke-linecap="round"/>
                            <line x1="175" y1="250" x2="185" y2="400" stroke="#F5DEB3" stroke-width="8" stroke-linecap="round"/>
                        </g>
                        <g id="anaLayerMuscle">
                            <ellipse cx="125" cy="130" rx="25" ry="30" fill="url(#muscleG)" opacity="0.8"/>
                            <ellipse cx="175" cy="130" rx="25" ry="30" fill="url(#muscleG)" opacity="0.8"/>
                            <rect x="130" y="160" width="40" height="60" rx="5" fill="url(#muscleG)" opacity="0.7"/>
                            <ellipse cx="125" cy="290" rx="20" ry="45" fill="url(#muscleG)" opacity="0.7"/>
                            <ellipse cx="175" cy="290" rx="20" ry="45" fill="url(#muscleG)" opacity="0.7"/>
                        </g>
                        <g id="anaLayerSkin">
                            <ellipse cx="150" cy="50" rx="35" ry="40" fill="url(#skinG)" opacity="0.9"/>
                            <rect x="140" y="85" width="20" height="15" fill="url(#skinG)" opacity="0.9"/>
                            <path d="M 100,100 Q 85,150 90,200 Q 95,230 110,250 L 190,250 Q 205,230 210,200 Q 215,150 200,100 Z" fill="url(#skinG)" opacity="0.9"/>
                            <path d="M 100,100 Q 80,120 65,170 Q 55,200 50,230" fill="none" stroke="#DEB887" stroke-width="20" stroke-linecap="round" opacity="0.9"/>
                            <path d="M 200,100 Q 220,120 235,170 Q 245,200 250,230" fill="none" stroke="#DEB887" stroke-width="20" stroke-linecap="round" opacity="0.9"/>
                            <path d="M 110,250 Q 105,300 108,350 Q 110,400 105,450" fill="none" stroke="#DEB887" stroke-width="28" stroke-linecap="round" opacity="0.9"/>
                            <path d="M 190,250 Q 195,300 192,350 Q 190,400 195,450" fill="none" stroke="#DEB887" stroke-width="28" stroke-linecap="round" opacity="0.9"/>
                        </g>
                        <g id="anaPoints">
                            <circle class="ana-pt" cx="108" cy="340" r="5" fill="#FFD700" data-pt="ST36" onclick="TCMVisuals._anaPoint('ST36')" style="cursor:pointer"/><text x="85" y="335" fill="#FFD700" font-size="8">ST36</text>
                            <circle class="ana-pt" cx="55" cy="210" r="5" fill="#FFD700" data-pt="LI4" onclick="TCMVisuals._anaPoint('LI4')" style="cursor:pointer"/><text x="35" y="205" fill="#FFD700" font-size="8">LI4</text>
                            <circle class="ana-pt" cx="115" cy="440" r="5" fill="#FFD700" data-pt="LV3" onclick="TCMVisuals._anaPoint('LV3')" style="cursor:pointer"/><text x="95" y="450" fill="#FFD700" font-size="8">LV3</text>
                            <circle class="ana-pt" cx="62" cy="185" r="5" fill="#FFD700" data-pt="PC6" onclick="TCMVisuals._anaPoint('PC6')" style="cursor:pointer"/><text x="40" y="180" fill="#FFD700" font-size="8">PC6</text>
                            <circle class="ana-pt" cx="100" cy="395" r="5" fill="#FFD700" data-pt="SP6" onclick="TCMVisuals._anaPoint('SP6')" style="cursor:pointer"/><text x="75" y="400" fill="#FFD700" font-size="8">SP6</text>
                            <circle class="ana-pt" cx="150" cy="200" r="5" fill="#FFD700" data-pt="CV6" onclick="TCMVisuals._anaPoint('CV6')" style="cursor:pointer"/><text x="158" y="205" fill="#FFD700" font-size="8">CV6</text>
                        </g>
                    </svg>
                </div>
                <div class="tcm-controls">
                    <h3>${HE.anaControls}</h3>
                    <div class="tcm-section">
                        <div class="tcm-section-title">${HE.layers}</div>
                        <div style="display:flex;flex-direction:column;gap:8px;">
                            <label style="display:flex;align-items:center;gap:10px;background:rgba(0,0,0,0.3);padding:10px;border-radius:8px;cursor:pointer;">
                                <input type="checkbox" checked onchange="TCMVisuals._anaToggle('Skin',this.checked)"> <span style="font-size:20px;">\u{1F9F4}</span> <span>${HE.skin}</span>
                            </label>
                            <label style="display:flex;align-items:center;gap:10px;background:rgba(0,0,0,0.3);padding:10px;border-radius:8px;cursor:pointer;">
                                <input type="checkbox" checked onchange="TCMVisuals._anaToggle('Muscle',this.checked)"> <span style="font-size:20px;">\u{1F4AA}</span> <span>${HE.muscle}</span>
                            </label>
                            <label style="display:flex;align-items:center;gap:10px;background:rgba(0,0,0,0.3);padding:10px;border-radius:8px;cursor:pointer;">
                                <input type="checkbox" checked onchange="TCMVisuals._anaToggle('Bone',this.checked)"> <span style="font-size:20px;">\u{1F9B4}</span> <span>${HE.bone}</span>
                            </label>
                        </div>
                    </div>
                    <div class="tcm-section">
                        <div class="tcm-section-title">${HE.presets}</div>
                        <div style="display:flex;gap:6px;flex-wrap:wrap;">
                            <button class="tcm-btn" style="border-color:#8B5CF6;color:#8B5CF6" onclick="TCMVisuals._anaPreset('all')">${HE.all}</button>
                            <button class="tcm-btn" style="border-color:#3498DB;color:#3498DB" onclick="TCMVisuals._anaPreset('xray')">${HE.xray}</button>
                            <button class="tcm-btn" style="border-color:#E74C3C;color:#E74C3C" onclick="TCMVisuals._anaPreset('muscle')">${HE.muscle}</button>
                            <button class="tcm-btn" style="border-color:#F5DEB3;color:#F5DEB3" onclick="TCMVisuals._anaPreset('bone')">${HE.bone}</button>
                        </div>
                    </div>
                    <div id="anaInfo" class="tcm-info-panel">
                        <h4 id="anaInfoTitle"></h4>
                        <p id="anaInfoDepth"></p>
                        <p id="anaInfoTip"></p>
                    </div>
                </div>
            </div>
        `;
    }
    
    function anaToggleLayer(layer, visible) {
        const el = document.getElementById('anaLayer' + layer);
        if (el) el.style.opacity = visible ? '1' : '0';
    }
    
    function anaPreset(type) {
        const checkboxes = document.querySelectorAll('.tcm-controls input[type="checkbox"]');
        if (type === 'all') {
            checkboxes.forEach(c => c.checked = true);
            anaToggleLayer('Skin', true); anaToggleLayer('Muscle', true); anaToggleLayer('Bone', true);
        } else if (type === 'xray') {
            checkboxes[0].checked = false; checkboxes[1].checked = false; checkboxes[2].checked = true;
            anaToggleLayer('Skin', false); anaToggleLayer('Muscle', false); anaToggleLayer('Bone', true);
        } else if (type === 'muscle') {
            checkboxes[0].checked = false; checkboxes[1].checked = true; checkboxes[2].checked = true;
            anaToggleLayer('Skin', false); anaToggleLayer('Muscle', true); anaToggleLayer('Bone', true);
        } else if (type === 'bone') {
            checkboxes[0].checked = false; checkboxes[1].checked = false; checkboxes[2].checked = true;
            anaToggleLayer('Skin', false); anaToggleLayer('Muscle', false); anaToggleLayer('Bone', true);
        }
    }
    
    function anaShowPoint(id) {
        document.querySelectorAll('.ana-pt').forEach(p => { p.setAttribute('r', '5'); p.style.filter = ''; });
        const pt = document.querySelector('.ana-pt[data-pt="' + id + '"]');
        if (pt) { pt.setAttribute('r', '8'); pt.style.filter = 'drop-shadow(0 0 10px #FFD700)'; }
        
        const p = acupoints[id];
        document.getElementById('anaInfo').classList.add('show');
        document.getElementById('anaInfoTitle').textContent = '\u{1F4CD} ' + p.name;
        document.getElementById('anaInfoDepth').innerHTML = '<strong>' + HE.depthLabel + '</strong> ' + p.depth;
        document.getElementById('anaInfoTip').innerHTML = '<strong>' + HE.tip + '</strong> ' + p.tip;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════
    
    window.TCMVisuals = {
        showMeridian: function() {
            injectStyles();
            createModal('tcm-meridian-modal', getMeridianHTML());
        },
        showEar: function() {
            injectStyles();
            createModal('tcm-ear-modal', getEarHTML());
        },
        showAnatomy: function() {
            injectStyles();
            createModal('tcm-anatomy-modal', getAnatomyHTML());
        },
        close: function(id) {
            closeModal(id);
        },
        // Internal methods
        _merSelect: merSelect,
        _merFilter: merFilter,
        _merStart: merStart,
        _merStop: merStop,
        _merSpeed: merSetSpeed,
        _earZone: earSelectZone,
        _earProtocol: earShowProtocol,
        _anaToggle: anaToggleLayer,
        _anaPreset: anaPreset,
        _anaPoint: anaShowPoint
    };
    
    console.log('\u2705 TCM Visualization Suite loaded!');
    console.log('   \u2192 TCMVisuals.showMeridian()');
    console.log('   \u2192 TCMVisuals.showEar()');
    console.log('   \u2192 TCMVisuals.showAnatomy()');
    
})();
