/**
 * TCM Body Images Gallery - Quick Module
 * Usage: BodyImages.show() or BodyImages.show(5) to start at specific image
 */
(function() {
    const BASE = 'https://iqfglrwjemogoycbzltt.supabase.co/storage/v1/object/public/tcm-body-images/body-parts/';
    const IMAGES = [
        {f:'front_full%20body.png', he:'גוף מלא - קדמי'},
        {f:'back_body.png', he:'גוף מלא - אחורי'},
        {f:'face_front.png', he:'פנים'},
        {f:'side_head.png', he:'ראש - צד'},
        {f:'ear.png', he:'אוזן'},
        {f:'tounge.png', he:'לשון'},
        {f:'arm_inner.png', he:'זרוע פנימית'},
        {f:'outer_arm.png', he:'זרוע חיצונית'},
        {f:'hand_dorsum.png', he:'גב כף יד'},
        {f:'hand_inner%20palmar.png', he:'כף יד'},
        {f:'leg_front.png', he:'רגל קדמית'},
        {f:'inner_leg.png', he:'רגל פנימית'},
        {f:'leg_outer.png', he:'רגל חיצונית'},
        {f:'foot_left.png', he:'כף רגל צד'},
        {f:'top_foot.png', he:'כף רגל מלמעלה'},
        {f:'body_baby.png', he:'תינוק'},
        {f:'chield_body%206-8%20years.png', he:'ילד 6-8'}
    ];
    let idx=0;
    
    function show(startIdx){
        // Set starting index if provided
        if(typeof startIdx === 'number' && startIdx >= 0 && startIdx < IMAGES.length) {
            idx = startIdx;
        }
        
        let m=document.getElementById('bi-modal');
        if(m)m.remove();
        m=document.createElement('div');
        m.id='bi-modal';
        m.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.95);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;';
        m.innerHTML=`
            <div style="color:white;font-size:20px;margin-bottom:10px;" id="bi-title">${IMAGES[idx].he}</div>
            <img id="bi-img" src="${BASE}${IMAGES[idx].f}" style="max-width:90%;max-height:70vh;border-radius:10px;">
            <div style="margin-top:15px;display:flex;gap:10px;">
                <button onclick="BodyImages.prev()" style="padding:10px 20px;background:#3498db;color:white;border:none;border-radius:8px;cursor:pointer;">← הקודם</button>
                <button onclick="BodyImages.next()" style="padding:10px 20px;background:#3498db;color:white;border:none;border-radius:8px;cursor:pointer;">הבא →</button>
                <button onclick="BodyImages.close()" style="padding:10px 20px;background:#e74c3c;color:white;border:none;border-radius:8px;cursor:pointer;">✕ סגור</button>
            </div>
            <div style="margin-top:15px;display:flex;flex-wrap:wrap;gap:5px;max-width:90%;justify-content:center;">
                ${IMAGES.map((img,i)=>`<button onclick="BodyImages.go(${i})" style="padding:5px 10px;background:${i===idx?'#e74c3c':'#333'};color:white;border:none;border-radius:5px;cursor:pointer;font-size:11px;">${img.he}</button>`).join('')}
            </div>
        `;
        document.body.appendChild(m);
    }
    
    function upd(){
        const img = document.getElementById('bi-img');
        const title = document.getElementById('bi-title');
        if(img) img.src = BASE + IMAGES[idx].f;
        if(title) title.textContent = IMAGES[idx].he;
        // Update thumbnail buttons
        const modal = document.getElementById('bi-modal');
        if(modal) {
            const buttons = modal.querySelectorAll('button');
            buttons.forEach((btn, i) => {
                // Skip nav buttons (first 3), update thumbnail buttons
                if(i >= 3 && i-3 < IMAGES.length) {
                    btn.style.background = (i-3 === idx) ? '#e74c3c' : '#333';
                }
            });
        }
    }
    
    function go(i){
        idx = i;
        const modal = document.getElementById('bi-modal');
        if(modal) {
            upd();
        } else {
            // Modal not open, open it at this index
            show(i);
        }
    }
    
    window.BodyImages={
        show,
        close:()=>{let m=document.getElementById('bi-modal');if(m)m.remove();},
        next:()=>{idx=(idx+1)%IMAGES.length;upd();},
        prev:()=>{idx=(idx-1+IMAGES.length)%IMAGES.length;upd();},
        go,
        url:(f)=>BASE+f,
        getAll:()=>IMAGES.map((img,i)=>({index:i, filename:img.f, hebrew:img.he, url:BASE+img.f})),
        getTongue:()=>({index:5, filename:IMAGES[5].f, hebrew:IMAGES[5].he, url:BASE+IMAGES[5].f}),
        // Show single image only (no gallery navigation)
        showSingle:(i)=>{
            const img = IMAGES[i] || IMAGES[5];
            let m=document.getElementById('bi-modal');
            if(m)m.remove();
            m=document.createElement('div');
            m.id='bi-modal';
            m.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.95);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;';
            m.innerHTML=`
                <div style="color:white;font-size:24px;margin-bottom:15px;font-weight:bold;">${img.he}</div>
                <img src="${BASE}${img.f}" style="max-width:90%;max-height:75vh;border-radius:10px;">
                <div style="margin-top:20px;">
                    <button onclick="BodyImages.close()" style="padding:12px 30px;background:#e74c3c;color:white;border:none;border-radius:8px;cursor:pointer;font-size:16px;font-weight:bold;">✕ סגור</button>
                    <button onclick="BodyImages.show(${IMAGES.indexOf(img)})" style="padding:12px 30px;background:#3498db;color:white;border:none;border-radius:8px;cursor:pointer;font-size:16px;margin-right:10px;">📷 פתח גלריה מלאה</button>
                </div>
            `;
            document.body.appendChild(m);
        },
        // Shortcut for tongue
        showTongue:()=>{ window.BodyImages.showSingle(5); }
    };
    console.log('✅ BodyImages loaded! Use BodyImages.show() or BodyImages.show(5) for tongue');
})();
