// ═══════════════════════════════════════════════════════════════
// AI-REPORT.JS - MINIMAL SAFETY VALIDATION
// Just logs warnings - no DOM changes
// ═══════════════════════════════════════════════════════════════

console.log('📦 AI-Report: Safety validation loading...');

const MEDICAL_PROTOCOL = {
    tcmKeywords: ['כאב', 'תסמונת', 'דיקור', 'נקודה', 'טיפול', 'יאנג', 'יין', 'דופק', 'acupuncture', 'meridian', 'qi', 'yin', 'yang'],
    safetyKeywords: {
        critical: ['אסור', 'forbidden', 'contraindicated', 'danger'],
        high: ['pregnancy', 'הריון', 'avoid', 'warning']
    }
};

// Validate TCM query
window.validateTCMQuery = function(queries) {
    const text = queries.join(' ').toLowerCase();
    const isTCM = MEDICAL_PROTOCOL.tcmKeywords.some(kw => text.includes(kw.toLowerCase()));
    const isNonMedical = /pizza|food|restaurant|shop|פיצה|אוכל/i.test(text);
    
    if (!isTCM && isNonMedical) {
        console.warn('⚠️ Non-TCM query detected:', queries);
        return { warning: '⚠️ Query not related to TCM' };
    }
    
    return { isTCMRelated: isTCM };
};

// Detect safety level
window.categorizeSafetyLevel = function(text) {
    const lower = text.toLowerCase();
    
    if (MEDICAL_PROTOCOL.safetyKeywords.critical.some(kw => lower.includes(kw.toLowerCase()))) {
        console.error('🔴 CRITICAL safety warning detected');
        return { level: 'critical', icon: '🔴' };
    }
    if (MEDICAL_PROTOCOL.safetyKeywords.high.some(kw => lower.includes(kw.toLowerCase()))) {
        console.warn('🟠 HIGH priority warning detected');
        return { level: 'high', icon: '🟠' };
    }
    
    return { level: 'normal', icon: '🟢' };
};

// Detect contradictions
window.detectContradictions = function(text) {
    const contradictions = [];
    const measurements = {};
    const matches = text.match(/([A-Z]{2}\d+).*?(\d+\.?\d*)\s*cun/gi);
    
    if (matches) {
        matches.forEach(match => {
            const point = match.match(/[A-Z]{2}\d+/i)[0];
            const measurement = match.match(/(\d+\.?\d*)\s*cun/i)[1];
            
            if (measurements[point] && measurements[point] !== measurement) {
                contradictions.push({ point, values: [measurements[point], measurement] });
                console.warn(`🚨 Contradiction: ${point} appears as ${measurements[point]} cun AND ${measurement} cun`);
            } else {
                measurements[point] = measurement;
            }
        });
    }
    
    return contradictions;
};

console.log('✅ AI safety validation active (logs only - no visual changes)');
