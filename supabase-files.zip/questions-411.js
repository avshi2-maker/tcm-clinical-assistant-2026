// ═══════════════════════════════════════════════════════════════
// QUESTIONS-411.JS - MINIMAL BOX 4 PROTECTION
// NO DOM changes - only function override
// ═══════════════════════════════════════════════════════════════

console.log('📦 Questions-411: Box 4 protection loading...');

// Track which box to paste into next
window.QUESTIONS_411_CONFIG = { nextBoxIndex: 1 };

// Override the paste function to skip Box 4
const originalPaste = window.pasteQuestionToQuery;

window.pasteQuestionToQuery = function(questionText) {
    let targetBox = window.QUESTIONS_411_CONFIG.nextBoxIndex;
    
    // Skip Box 4
    if (targetBox === 4) {
        targetBox = 1;
        window.QUESTIONS_411_CONFIG.nextBoxIndex = 1;
    }
    
    // Paste to target box
    const textarea = document.getElementById(`query${targetBox}`);
    if (textarea) {
        textarea.value = questionText;
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        
        // Move to next box (1→2→3→1)
        window.QUESTIONS_411_CONFIG.nextBoxIndex++;
        if (window.QUESTIONS_411_CONFIG.nextBoxIndex > 3) {
            window.QUESTIONS_411_CONFIG.nextBoxIndex = 1;
        }
    }
};

console.log('✅ Box 4 LOCKED - questions paste to Box 1→2→3 only');
