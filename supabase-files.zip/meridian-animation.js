/**
 * ═══════════════════════════════════════════════════════════════
 * 🌊 MERIDIAN ANIMATION MODULE v1.0
 * ═══════════════════════════════════════════════════════════════
 * 
 * Interactive meridian visualization with animated Qi flow
 * 
 * Features:
 * - 12 Main Meridians (6 Yin + 6 Yang)
 * - Animated Qi flow particles
 * - Click meridian to highlight + show points
 * - Hebrew + Chinese names
 * - Five Elements color coding
 * 
 * Upload to: Supabase Storage → modules → meridian-animation.js
 * 
 * Usage:
 *   MeridianMap.show('containerId');
 *   MeridianMap.showModal();
 *   MeridianMap.selectMeridian('LU');
 * 
 * ═══════════════════════════════════════════════════════════════
 */

console.log('🌊 Loading Meridian Animation module...');

window.MeridianMap = (function() {
    
    // ═══════════════════════════════════════════════════════════
    // MERIDIAN DATA - 12 Main Channels
    // ═══════════════════════════════════════════════════════════
    const meridians = {
        // YIN MERIDIANS
        LU: {
            name: 'Lung', nameHe: 'ריאות', nameCn: '肺经',
            type: 'yin', element: 'Metal', elementHe: 'מתכת',
            color: '#87CEEB', flowDir: 'down',
            points: ['LU1','LU5','LU7','LU9','LU11'],
            path: 'M 140,130 Q 120,160 110,200 Q 100,250 90,300 Q 80,350 70,400',
            desc: 'שולט בנשימה, עור, ומערכת החיסון'
        },
        SP: {
            name: 'Spleen', nameHe: 'טחול', nameCn: '脾经',
            type: 'yin', element: 'Earth', elementHe: 'אדמה',
            color: '#FFD700', flowDir: 'up',
            points: ['SP1','SP3','SP6','SP9','SP10'],
            path: 'M 175,580 Q 170,500 165,420 Q 160,340 155,260 Q 150,180 145,130',
            desc: 'שולט בעיכול והפקת אנרגיה'
        },
        HT: {
            name: 'Heart', nameHe: 'לב', nameCn: '心经',
            type: 'yin', element: 'Fire', elementHe: 'אש',
            color: '#FF4444', flowDir: 'down',
            points: ['HT1','HT3','HT5','HT7','HT9'],
            path: 'M 150,135 Q 135,170 125,220 Q 115,280 105,340 Q 95,380 85,410',
            desc: 'שולט בדם, כלי דם, ותודעה'
        },
        KI: {
            name: 'Kidney', nameHe: 'כליות', nameCn: '肾经',
            type: 'yin', element: 'Water', elementHe: 'מים',
            color: '#4169E1', flowDir: 'up',
            points: ['KI1','KI3','KI6','KI7','KI27'],
            path: 'M 190,590 Q 185,500 180,420 Q 175,340 170,260 Q 165,180 160,130',
            desc: 'שולט בצמיחה, התפתחות, ורבייה'
        },
        PC: {
            name: 'Pericardium', nameHe: 'פריקרד', nameCn: '心包经',
            type: 'yin', element: 'Fire', elementHe: 'אש',
            color: '#DC143C', flowDir: 'down',
            points: ['PC1','PC3','PC6','PC7','PC9'],
            path: 'M 145,135 Q 130,180 120,240 Q 110,300 100,360 Q 90,400 80,430',
            desc: 'מגן על הלב, שולט ברגשות'
        },
        LV: {
            name: 'Liver', nameHe: 'כבד', nameCn: '肝经',
            type: 'yin', element: 'Wood', elementHe: 'עץ',
            color: '#32CD32', flowDir: 'up',
            points: ['LV1','LV2','LV3','LV8','LV14'],
            path: 'M 200,585 Q 195,500 190,420 Q 185,340 180,260 Q 175,180 170,130',
            desc: 'שולט בזרימת צ\'י ואחסון דם'
        },
        
        // YANG MERIDIANS
        LI: {
            name: 'Large Intestine', nameHe: 'מעי גס', nameCn: '大肠经',
            type: 'yang', element: 'Metal', elementHe: 'מתכת',
            color: '#E0E0E0', flowDir: 'up',
            points: ['LI1','LI4','LI10','LI11','LI20'],
            path: 'M 70,400 Q 85,340 100,280 Q 115,220 130,160 Q 145,120 165,80',
            desc: 'שולט בהפרשה וניקוי'
        },
        ST: {
            name: 'Stomach', nameHe: 'קיבה', nameCn: '胃经',
            type: 'yang', element: 'Earth', elementHe: 'אדמה',
            color: '#FFA500', flowDir: 'down',
            points: ['ST1','ST8','ST25','ST36','ST44'],
            path: 'M 180,70 Q 185,120 190,180 Q 195,260 200,340 Q 205,420 210,500 Q 215,560 220,600',
            desc: 'שולט בקבלת ועיכול מזון'
        },
        SI: {
            name: 'Small Intestine', nameHe: 'מעי דק', nameCn: '小肠经',
            type: 'yang', element: 'Fire', elementHe: 'אש',
            color: '#FF6347', flowDir: 'up',
            points: ['SI1','SI3','SI5','SI11','SI19'],
            path: 'M 85,410 Q 100,350 115,290 Q 130,230 150,170 Q 170,120 190,70',
            desc: 'מפריד בין טהור לעכור'
        },
        BL: {
            name: 'Bladder', nameHe: 'שלפוחית', nameCn: '膀胱经',
            type: 'yang', element: 'Water', elementHe: 'מים',
            color: '#0000CD', flowDir: 'down',
            points: ['BL1','BL10','BL23','BL40','BL67'],
            path: 'M 210,50 Q 220,100 225,180 Q 230,280 235,380 Q 240,480 245,580',
            desc: 'שולט באחסון והפרשת שתן'
        },
        SJ: {
            name: 'San Jiao', nameHe: 'סאן ג\'יאו', nameCn: '三焦经',
            type: 'yang', element: 'Fire', elementHe: 'אש',
            color: '#FF8C00', flowDir: 'up',
            points: ['SJ1','SJ5','SJ6','SJ17','SJ23'],
            path: 'M 80,430 Q 95,370 115,310 Q 135,250 155,190 Q 175,130 200,70',
            desc: 'שולט בתנועת נוזלים ואנרגיה'
        },
        GB: {
            name: 'Gallbladder', nameHe: 'כיס מרה', nameCn: '胆经',
            type: 'yang', element: 'Wood', elementHe: 'עץ',
            color: '#00FF00', flowDir: 'down',
            points: ['GB1','GB20','GB21','GB34','GB44'],
            path: 'M 230,60 Q 240,120 245,200 Q 250,300 255,400 Q 260,500 265,590',
            desc: 'שולט בקבלת החלטות ותעוזה'
        }
    };
    
    // State
    let currentMeridian = null;
    let animationRunning = false;
    let flowSpeed = 1;
    
    // ═══════════════════════════════════════════════════════════
    // GENERATE SVG
    // ═══════════════════════════════════════════════════════════
    function generateSVG() {
        return `
        <svg id="meridianSVG" viewBox="0 0 400 650" style="max-width: 100%; height: auto; background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%); border-radius: 12px;">
            <defs>
                <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="3" result="blur"/>
                    <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
                </filter>
                <filter id="strongGlow" x="-100%" y="-100%" width="300%" height="300%">
                    <feGaussianBlur stdDeviation="6" result="blur"/>
                    <feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
                </filter>
            </defs>
            
            <!-- Body Silhouette -->
            <g id="body" opacity="0.9">
                <!-- Head -->
                <ellipse cx="200" cy="55" rx="38" ry="48" fill="#2d3748" stroke="#4a5568" stroke-width="2"/>
                <!-- Neck -->
                <rect x="185" y="98" width="30" height="22" fill="#2d3748"/>
                <!-- Torso -->
                <path d="M 150,120 Q 135,180 140,280 Q 145,380 160,420 L 240,420 Q 255,380 260,280 Q 265,180 250,120 Z" 
                      fill="#2d3748" stroke="#4a5568" stroke-width="2"/>
                <!-- Left Arm -->
                <path d="M 150,125 Q 120,150 95,220 Q 75,290 60,360 Q 50,410 45,450" 
                      fill="none" stroke="#2d3748" stroke-width="28" stroke-linecap="round"/>
                <!-- Right Arm -->
                <path d="M 250,125 Q 280,150 305,220 Q 325,290 340,360 Q 350,410 355,450" 
                      fill="none" stroke="#2d3748" stroke-width="28" stroke-linecap="round"/>
                <!-- Left Leg -->
                <path d="M 160,420 Q 155,490 150,560 Q 148,600 145,640" 
                      fill="none" stroke="#2d3748" stroke-width="32" stroke-linecap="round"/>
                <!-- Right Leg -->
                <path d="M 240,420 Q 245,490 250,560 Q 252,600 255,640" 
                      fill="none" stroke="#2d3748" stroke-width="32" stroke-linecap="round"/>
            </g>
            
            <!-- Meridian Lines -->
            <g id="meridianLines">
                ${Object.entries(meridians).map(([code, m]) => `
                    <path id="path-${code}" d="${m.path}" 
                          fill="none" stroke="${m.color}" stroke-width="3" 
                          stroke-linecap="round" opacity="0.4"
                          style="cursor: pointer; transition: all 0.3s;"
                          onclick="MeridianMap.selectMeridian('${code}')"/>
                `).join('')}
            </g>
            
            <!-- Qi Particles Container -->
            <g id="qiParticles"></g>
            
            <!-- Labels -->
            <text id="meridianLabel" x="200" y="630" text-anchor="middle" 
                  fill="#fff" font-size="14" font-weight="bold" opacity="0"></text>
        </svg>
        `;
    }
    
    // ═══════════════════════════════════════════════════════════
    // GENERATE CONTROLS
    // ═══════════════════════════════════════════════════════════
    function generateControls() {
        return `
        <div style="background: linear-gradient(135deg, #1e3a5f 0%, #2d1b4e 100%); padding: 16px; border-radius: 12px; color: white; min-width: 260px;">
            <h3 style="margin: 0 0 12px 0; text-align: center; font-size: 18px;">🌊 מפת מרידיאנים</h3>
            
            <!-- Yin/Yang Filter -->
            <div style="display: flex; gap: 8px; margin-bottom: 12px;">
                <button onclick="MeridianMap.filterType('all')" style="flex:1; padding: 8px; border-radius: 8px; border: none; background: #4a5568; color: white; cursor: pointer;">הכל</button>
                <button onclick="MeridianMap.filterType('yin')" style="flex:1; padding: 8px; border-radius: 8px; border: none; background: #553c9a; color: white; cursor: pointer;">☯ יין</button>
                <button onclick="MeridianMap.filterType('yang')" style="flex:1; padding: 8px; border-radius: 8px; border: none; background: #c53030; color: white; cursor: pointer;">☯ יאנג</button>
            </div>
            
            <!-- Meridian Buttons - YIN -->
            <div style="margin-bottom: 8px;">
                <p style="font-size: 11px; color: #a0aec0; margin: 0 0 4px 0;">יין (Yin):</p>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px;">
                    ${Object.entries(meridians).filter(([_,m]) => m.type === 'yin').map(([code, m]) => `
                        <button onclick="MeridianMap.selectMeridian('${code}')" 
                                style="padding: 6px 4px; border-radius: 6px; border: 2px solid ${m.color}; 
                                       background: ${m.color}22; color: ${m.color}; cursor: pointer; font-size: 11px; font-weight: bold;"
                                id="btn-${code}">
                            ${code}<br><span style="font-size: 9px;">${m.nameHe}</span>
                        </button>
                    `).join('')}
                </div>
            </div>
            
            <!-- Meridian Buttons - YANG -->
            <div style="margin-bottom: 12px;">
                <p style="font-size: 11px; color: #a0aec0; margin: 0 0 4px 0;">יאנג (Yang):</p>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px;">
                    ${Object.entries(meridians).filter(([_,m]) => m.type === 'yang').map(([code, m]) => `
                        <button onclick="MeridianMap.selectMeridian('${code}')" 
                                style="padding: 6px 4px; border-radius: 6px; border: 2px solid ${m.color}; 
                                       background: ${m.color}22; color: ${m.color}; cursor: pointer; font-size: 11px; font-weight: bold;"
                                id="btn-${code}">
                            ${code}<br><span style="font-size: 9px;">${m.nameHe}</span>
                        </button>
                    `).join('')}
                </div>
            </div>
            
            <!-- Animation Controls -->
            <div style="display: flex; gap: 8px; margin-bottom: 12px;">
                <button onclick="MeridianMap.startFlow()" id="btnStart" 
                        style="flex: 1; padding: 10px; border-radius: 8px; border: none; background: #38a169; color: white; cursor: pointer; font-weight: bold;">
                    ▶️ הפעל זרימה
                </button>
                <button onclick="MeridianMap.stopFlow()" id="btnStop" 
                        style="flex: 1; padding: 10px; border-radius: 8px; border: none; background: #e53e3e; color: white; cursor: pointer; font-weight: bold;" disabled>
                    ⏹️ עצור
                </button>
            </div>
            
            <!-- Speed Control -->
            <div style="margin-bottom: 12px;">
                <label style="font-size: 12px;">מהירות: <span id="speedVal">1x</span></label>
                <input type="range" min="0.5" max="3" step="0.5" value="1" 
                       onchange="MeridianMap.setSpeed(this.value)"
                       style="width: 100%; margin-top: 4px;">
            </div>
            
            <!-- Info Panel -->
            <div id="infoPanel" style="background: rgba(255,255,255,0.1); padding: 12px; border-radius: 8px; display: none;">
                <h4 id="infoTitle" style="margin: 0 0 8px 0; font-size: 16px;"></h4>
                <p id="infoElement" style="margin: 0 0 4px 0; font-size: 12px;"></p>
                <p id="infoDesc" style="margin: 0 0 8px 0; font-size: 12px; color: #cbd5e0;"></p>
                <p id="infoPoints" style="margin: 0; font-size: 11px;"></p>
            </div>
        </div>
        `;
    }
    
    // ═══════════════════════════════════════════════════════════
    // ANIMATION - QI FLOW
    // ═══════════════════════════════════════════════════════════
    function animateQiFlow(code) {
        if (!animationRunning) return;
        
        const m = meridians[code];
        const path = document.getElementById(`path-${code}`);
        if (!path) return;
        
        const pathLength = path.getTotalLength();
        const particlesGroup = document.getElementById('qiParticles');
        
        // Create particle
        const particle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        particle.setAttribute('r', '6');
        particle.setAttribute('fill', m.color);
        particle.setAttribute('filter', 'url(#strongGlow)');
        particlesGroup.appendChild(particle);
        
        let progress = m.flowDir === 'up' ? pathLength : 0;
        const speed = (m.flowDir === 'up' ? -1 : 1) * 3 * flowSpeed;
        
        function animate() {
            if (!animationRunning) {
                particle.remove();
                return;
            }
            
            progress += speed;
            
            // Check bounds
            if ((m.flowDir === 'up' && progress < 0) || (m.flowDir === 'down' && progress > pathLength)) {
                particle.remove();
                // Restart with new particle
                setTimeout(() => animateQiFlow(code), 200 / flowSpeed);
                return;
            }
            
            const point = path.getPointAtLength(Math.abs(progress));
            particle.setAttribute('cx', point.x);
            particle.setAttribute('cy', point.y);
            
            requestAnimationFrame(animate);
        }
        
        animate();
    }
    
    // ═══════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════
    return {
        
        /**
         * Display meridian map in container
         */
        show: function(containerId) {
            const container = document.getElementById(containerId);
            if (!container) {
                console.error('❌ Container not found:', containerId);
                return;
            }
            
            container.innerHTML = `
                <div style="display: flex; gap: 16px; flex-wrap: wrap; justify-content: center; direction: rtl;">
                    <div style="flex: 1; min-width: 280px; max-width: 400px;">
                        ${generateSVG()}
                    </div>
                    <div style="flex: 0 0 auto;">
                        ${generateControls()}
                    </div>
                </div>
            `;
            
            console.log('✅ Meridian Map displayed');
        },
        
        /**
         * Show as popup modal
         */
        showModal: function() {
            let modal = document.getElementById('meridian-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'meridian-modal';
                modal.innerHTML = `
                    <div style="position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 9999; 
                                display: flex; align-items: center; justify-content: center; padding: 20px;">
                        <div style="background: #1a1a2e; border-radius: 16px; max-width: 900px; width: 100%; 
                                    max-height: 90vh; overflow: auto; position: relative; padding: 20px;">
                            <button onclick="MeridianMap.closeModal()" 
                                    style="position: absolute; top: 10px; left: 10px; width: 36px; height: 36px; 
                                           border-radius: 50%; border: none; background: #e53e3e; color: white; 
                                           font-size: 20px; cursor: pointer; z-index: 10;">✕</button>
                            <div id="meridian-modal-content"></div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
            }
            
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            this.show('meridian-modal-content');
        },
        
        /**
         * Close modal
         */
        closeModal: function() {
            this.stopFlow();
            const modal = document.getElementById('meridian-modal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        },
        
        /**
         * Select and highlight a meridian
         */
        selectMeridian: function(code) {
            if (!meridians[code]) return;
            
            this.stopFlow();
            currentMeridian = code;
            const m = meridians[code];
            
            // Reset all paths
            Object.keys(meridians).forEach(c => {
                const p = document.getElementById(`path-${c}`);
                const b = document.getElementById(`btn-${c}`);
                if (p) {
                    p.setAttribute('opacity', '0.3');
                    p.setAttribute('stroke-width', '3');
                    p.removeAttribute('filter');
                }
                if (b) b.style.transform = 'scale(1)';
            });
            
            // Highlight selected
            const path = document.getElementById(`path-${code}`);
            const btn = document.getElementById(`btn-${code}`);
            if (path) {
                path.setAttribute('opacity', '1');
                path.setAttribute('stroke-width', '5');
                path.setAttribute('filter', 'url(#strongGlow)');
            }
            if (btn) btn.style.transform = 'scale(1.1)';
            
            // Update label
            const label = document.getElementById('meridianLabel');
            if (label) {
                label.textContent = `${m.nameHe} (${code}) - ${m.nameCn}`;
                label.setAttribute('opacity', '1');
            }
            
            // Show info panel
            const panel = document.getElementById('infoPanel');
            if (panel) {
                panel.style.display = 'block';
                document.getElementById('infoTitle').innerHTML = `<span style="color:${m.color}">${m.nameCn}</span> ${m.nameHe} (${code})`;
                document.getElementById('infoElement').innerHTML = `יסוד: <strong style="color:${m.color}">${m.elementHe}</strong> | ${m.type === 'yin' ? '☯ יין' : '☯ יאנג'}`;
                document.getElementById('infoDesc').textContent = m.desc;
                document.getElementById('infoPoints').innerHTML = `<strong>נקודות:</strong> ${m.points.join(', ')}`;
            }
            
            console.log(`🎯 Selected: ${m.nameHe} (${code})`);
        },
        
        /**
         * Filter by Yin/Yang
         */
        filterType: function(type) {
            Object.entries(meridians).forEach(([code, m]) => {
                const path = document.getElementById(`path-${code}`);
                const btn = document.getElementById(`btn-${code}`);
                const show = type === 'all' || m.type === type;
                if (path) path.setAttribute('opacity', show ? '0.5' : '0.1');
                if (btn) btn.style.opacity = show ? '1' : '0.3';
            });
        },
        
        /**
         * Start Qi flow animation
         */
        startFlow: function() {
            if (!currentMeridian) {
                alert('בחר מרידיאן תחילה!');
                return;
            }
            
            animationRunning = true;
            document.getElementById('btnStart').disabled = true;
            document.getElementById('btnStop').disabled = false;
            
            // Start multiple particles
            animateQiFlow(currentMeridian);
            setTimeout(() => animateQiFlow(currentMeridian), 400);
            setTimeout(() => animateQiFlow(currentMeridian), 800);
            
            console.log(`🌊 Qi flow started: ${meridians[currentMeridian].nameHe}`);
        },
        
        /**
         * Stop animation
         */
        stopFlow: function() {
            animationRunning = false;
            const particles = document.getElementById('qiParticles');
            if (particles) particles.innerHTML = '';
            
            const startBtn = document.getElementById('btnStart');
            const stopBtn = document.getElementById('btnStop');
            if (startBtn) startBtn.disabled = false;
            if (stopBtn) stopBtn.disabled = true;
            
            console.log('⏹️ Animation stopped');
        },
        
        /**
         * Set animation speed
         */
        setSpeed: function(val) {
            flowSpeed = parseFloat(val);
            const speedVal = document.getElementById('speedVal');
            if (speedVal) speedVal.textContent = `${val}x`;
        },
        
        /**
         * Get meridian data
         */
        getData: function(code) {
            return meridians[code] || null;
        },
        
        /**
         * Get all meridians
         */
        getAll: function() {
            return {...meridians};
        },
        
        /**
         * Highlight from acupoint code (for search integration)
         */
        highlightFromAcupoint: function(pointCode) {
            const match = pointCode.match(/^([A-Z]{2})/i);
            if (match && meridians[match[1].toUpperCase()]) {
                this.selectMeridian(match[1].toUpperCase());
            }
        }
    };
})();

// ═══════════════════════════════════════════════════════════════
console.log('✅ Meridian Animation module loaded!');
console.log('   → MeridianMap.show("containerId")');
console.log('   → MeridianMap.showModal()');
